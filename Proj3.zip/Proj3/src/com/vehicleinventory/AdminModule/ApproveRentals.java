package com.vehicleinventory.AdminModule;

import com.vehicleinventory.Database.RentRequestDAO;
import com.vehicleinventory.Models.RentRequest;
import com.vehicleinventory.Models.User;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ApproveRentals extends JPanel {
    private RentRequestDAO rentRequestDAO;
    private JPanel requestsPanel;
    private JScrollPane scrollPane;
    private Image backgroundImage;

    public ApproveRentals(CardLayout cardLayout, JPanel mainPanel) {
        rentRequestDAO = new RentRequestDAO();
        setLayout(new BorderLayout());

        backgroundImage = new ImageIcon(getClass().getResource("/resources/ex1.jpeg")).getImage();

        JLabel titleLabel = new JLabel("Pending Rent Requests", JLabel.CENTER);
        titleLabel.setFont(new Font("Open Sans", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titleLabel, BorderLayout.NORTH);

        // Panel for back and refresh buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        // Back Button
        JButton backButton = createButton("Back", new Color(100, 150, 255), Color.WHITE);
        backButton.addActionListener(e -> {
            cardLayout.show(mainPanel, "AdminDashboard");
        });

        // Refresh Button
        JButton refreshButton = createButton("Refresh", new Color(100, 200, 100), Color.WHITE);
        refreshButton.addActionListener(e -> {
            refreshRequests();  // Call to refresh the requests
        });

        buttonPanel.add(backButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        requestsPanel = new JPanel();
        requestsPanel.setLayout(new BoxLayout(requestsPanel, BoxLayout.Y_AXIS));
        requestsPanel.setOpaque(false);

        scrollPane = new JScrollPane(requestsPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);

        refreshRequests();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        } else {
            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    private JPanel createRequestPanel(RentRequest request) {
        JPanel requestPanel = new JPanel();
        requestPanel.setLayout(new BorderLayout());
        requestPanel.setBorder(BorderFactory.createTitledBorder("Request ID: " + request.getRequestId()));
        requestPanel.setBackground(new Color(255, 255, 255, 200));

        int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
        int panelWidth = (int) (screenWidth * 0.8);
        requestPanel.setPreferredSize(new Dimension(panelWidth, 80));
        requestPanel.setMinimumSize(new Dimension(panelWidth, 80));
        requestPanel.setMaximumSize(new Dimension(panelWidth, 80));

        JPanel vehicleDetailsPanel = new JPanel();
        vehicleDetailsPanel.setLayout(new GridLayout(2, 1));
        vehicleDetailsPanel.add(new JLabel("Vehicle Make: " + request.getVehicle().getMake()));
        vehicleDetailsPanel.add(new JLabel("Vehicle Model: " + request.getVehicle().getModel()));
        requestPanel.add(vehicleDetailsPanel, BorderLayout.CENTER);

        JButton viewDetailsButton = createButton("View Details", new Color(100, 150, 255), Color.WHITE);
        viewDetailsButton.addActionListener(e -> showDetailsDialog(request));
        requestPanel.add(viewDetailsButton, BorderLayout.EAST);

        return requestPanel;
    }

    private JButton createButton(String text, Color background, Color foreground) {
        JButton button = new JButton(text);
        button.setBackground(background);
        button.setForeground(foreground);
        button.setFont(new Font("Open Sans", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(120, 40));
        button.setFocusPainted(false);
        return button;
    }

    public void refreshRequests() {
        requestsPanel.removeAll();
        List<RentRequest> pendingRequests = rentRequestDAO.getPendingRentRequests();

        for (RentRequest request : pendingRequests) {
            requestsPanel.add(createRequestPanel(request));
        }

        requestsPanel.revalidate();
        requestsPanel.repaint();
    }

    private void showDetailsDialog(RentRequest request) {
        // Create dialog for detailed view
        JDialog detailsDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Request Details", true);
        detailsDialog.setLayout(new BorderLayout());
        detailsDialog.setSize(500, 400);
        detailsDialog.setLocationRelativeTo(this);

        // Panel for details
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new GridLayout(8, 1));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        User user = request.getUser(); // Assuming RentRequest has a getUser() method
        detailsPanel.add(new JLabel("User Name: " + user.getUsername()));
        detailsPanel.add(new JLabel("User Email: " + user.getEmail()));
//        detailsPanel.add(new JLabel("User Phone: " + user.getPhone()));

        detailsPanel.add(new JLabel("Vehicle Make: " + request.getVehicle().getMake()));
        detailsPanel.add(new JLabel("Vehicle Model: " + request.getVehicle().getModel()));
        detailsPanel.add(new JLabel("Vehicle Year: " + request.getVehicle().getYear()));
        detailsPanel.add(new JLabel("Rent Price: $" + request.getVehicle().getPrice()));
        detailsPanel.add(new JLabel("Request Date: " + request.getRequestDate()));

        detailsDialog.add(detailsPanel, BorderLayout.CENTER);

        // Panel for Approve and Reject buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        JButton approveButton = createButton("Approve", new Color(100, 200, 100), new Color(0, 150, 0));
        approveButton.addActionListener(e -> {
            rentRequestDAO.approveRentRequest(request.getRequestId());
            JOptionPane.showMessageDialog(this, "Rent request approved.");
            refreshRequests();
            detailsDialog.dispose();
        });

        JButton rejectButton = createButton("Reject", new Color(255, 100, 100), new Color(200, 0, 0));
        rejectButton.addActionListener(e -> {
            rentRequestDAO.rejectRentRequest(request.getRequestId());
            JOptionPane.showMessageDialog(this, "Rent request rejected.");
            refreshRequests();
            detailsDialog.dispose();
        });

        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        detailsDialog.add(buttonPanel, BorderLayout.SOUTH);

        detailsDialog.setVisible(true);
    }

    public static void main(String[] args) {
        // Set up the main frame
        JFrame frame = new JFrame("Approve Rentals");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600); // Set a reasonable frame size
        frame.setLocationRelativeTo(null); // Center the frame

        // Create a CardLayout and main panel to simulate the navigation behavior
        CardLayout cardLayout = new CardLayout();
        JPanel mainPanel = new JPanel(cardLayout);

        // Instantiate the ApproveRentals panel with CardLayout and mainPanel
        ApproveRentals approveRentalsPanel = new ApproveRentals(cardLayout, mainPanel);

        // Add ApproveRentals panel to the main panel with a name
        mainPanel.add(approveRentalsPanel, "ApproveRentals");

        // Set up an example AdminDashboard panel to switch back to (for back button functionality)
        JPanel adminDashboardPanel = new JPanel();
        adminDashboardPanel.add(new JLabel("Admin Dashboard"));
        mainPanel.add(adminDashboardPanel, "AdminDashboard");

        // Add the main panel to the frame and show the ApproveRentals panel
        frame.add(mainPanel);
        cardLayout.show(mainPanel, "ApproveRentals");

        // Make the frame visible
        frame.setVisible(true);
    }
}
