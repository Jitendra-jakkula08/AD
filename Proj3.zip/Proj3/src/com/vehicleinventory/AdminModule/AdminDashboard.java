package com.vehicleinventory.AdminModule;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.NotificationManager;
import com.vehicleinventory.UserModule.NotificationsPanel;

public class AdminDashboard extends JPanel {
    private final CardLayout cardLayout;
    private final JPanel mainPanel;
    private final NotificationManager notificationManager;
    private final VehicleDAO vehicleDAO;

    public AdminDashboard(CardLayout cardLayout, JPanel mainPanel) {
        this.cardLayout = cardLayout;
        this.mainPanel = mainPanel;
        this.notificationManager = new NotificationManager();
        this.vehicleDAO = new VehicleDAO(); // Instantiate VehicleDAO here

        setLayout(new BorderLayout());
        setBackground(Color.decode("#F5F5F5"));

        // Add background image
        JLabel backgroundLabel = new JLabel(new ImageIcon(getClass().getResource("/resources/admin.jpg")));

        backgroundLabel.setLayout(null);
        backgroundLabel.setPreferredSize(new Dimension(600, 800));

        // Create NotificationsPanel instance
        NotificationsPanel notificationsPanel = new NotificationsPanel(cardLayout, mainPanel);
        // Create and add panels to the main panel
        initializePanels(notificationsPanel);

        // Create and position header labels
        addHeaderLabels(backgroundLabel);

        // Add background label to the main panel
        add(backgroundLabel, BorderLayout.CENTER);
    }

    private void initializePanels(NotificationsPanel notificationsPanel) {
        JPanel addVehiclePanel = new AddVehicle(cardLayout, mainPanel);
        JPanel approveRentalsPanel = new ApproveRentals(cardLayout, mainPanel);
        JPanel approveSalesPanel = new ApproveSales(cardLayout, mainPanel);
//        JPanel updateVehiclePanel = new UpdateVehicle();

        // Pass only required parameters to the ApproveBuyPanel constructor
        JPanel approveBuyPanel = new ApproveBuyPanel(cardLayout, mainPanel, vehicleDAO, notificationsPanel);

        // Add panels to mainPanel with their respective names
        mainPanel.add(addVehiclePanel, "AddVehicle");
        mainPanel.add(approveRentalsPanel, "ApproveRentals");
        mainPanel.add(approveSalesPanel, "ApproveSales");
//        mainPanel.add(updateVehiclePanel, "UpdateVehicle");
        mainPanel.add(approveBuyPanel, "ApproveBuy");
    }

    private void addHeaderLabels(JLabel backgroundLabel) {
        String[] headers = {
            "Add Vehicle", 
            "Approve Rentals", 
            "Approve Sales", 
//            "Update Vehicle", 
            "Approve Buy Requests"
        };

        int headerHeight = 50;
        int headerWidth = 200;
        int yPosition = 50;

        for (String header : headers) {
            JLabel headerLabel = createHeaderLabel(header);
            headerLabel.setBounds(100, yPosition, headerWidth, headerHeight);
            headerLabel.addMouseListener(createHeaderListener(header)); 
            backgroundLabel.add(headerLabel);
            yPosition += 70; 
        }
    }

    private JLabel createHeaderLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        label.setForeground(Color.WHITE);
        label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        label.setPreferredSize(new Dimension(200, 50));
        label.setOpaque(true);
        label.setBackground(Color.decode("#1976D2")); // Header background color
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2)); // Add border for improved visibility
        return label;
    }

    private MouseAdapter createHeaderListener(String header) {
        return new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String panelName;
                switch (header) {
                    case "Add Vehicle":
                        panelName = "AddVehicle";
                        break;
                    case "Approve Rentals":
                        panelName = "ApproveRentals";
                        break;
                    case "Approve Sales":
                        panelName = "ApproveSales";
                        break;
//                    case "Update Vehicle":
//                        panelName = "UpdateVehicle";
//                        break;
                    case "Approve Buy Requests":
                        panelName = "ApproveBuy";
                        break;
                    default:
                        panelName = "";
                }
                
                System.out.println("Switching to: " + panelName); // Debugging output
                cardLayout.show(mainPanel, panelName);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                ((JLabel) e.getSource()).setBackground(Color.decode("#1565C0")); // Darken background on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                ((JLabel) e.getSource()).setBackground(Color.decode("#1976D2")); // Reset background
            }
        };
    }

    // Main method for debugging
    public static void main(String[] args) {
        JFrame frame = new JFrame("Admin Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 600);
        CardLayout cardLayout = new CardLayout();
        JPanel mainPanel = new JPanel(cardLayout);

        AdminDashboard adminDashboard = new AdminDashboard(cardLayout, mainPanel);
        mainPanel.add(adminDashboard, "AdminDashboard"); // Add adminDashboard to mainPanel
        frame.add(mainPanel); // Add mainPanel to the frame
        frame.setVisible(true); 

        // Show initial panel
        cardLayout.show(mainPanel, "AdminDashboard");
    }
}
