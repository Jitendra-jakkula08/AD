package com.vehicleinventory.AdminModule;

import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.Models.BuyRequest;
import com.vehicleinventory.Models.Notification;
import com.vehicleinventory.NotificationManager;
import com.vehicleinventory.UserModule.NotificationsPanel;
import com.vehicleinventory.Models.Vehicle;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

public class ApproveBuyPanel extends JPanel {
    private JTable buyRequestTable;
    private Image backgroundImage;
    private final VehicleDAO vehicleDAO;
    private final NotificationsPanel notificationsPanel;

    public ApproveBuyPanel(CardLayout cardLayout, JPanel mainPanel, VehicleDAO vehicleDAO, NotificationsPanel notificationsPanel) {
        this.vehicleDAO = vehicleDAO;
        this.notificationsPanel = notificationsPanel;

        // Load background image
        try {
            backgroundImage = ImageIO.read(getClass().getClassLoader().getResourceAsStream("resources/inventory.jpeg")); // Use your desired background image
        } catch (IOException e) {
            e.printStackTrace();
        }

        setLayout(new BorderLayout());

        // Title Panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(240, 240, 240, 200)); // Semi-transparent background
        JLabel titleLabel = new JLabel("Approve Buy Requests");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Table to display buy requests
        buyRequestTable = createStyledTable();
        JScrollPane scrollPane = new JScrollPane(buyRequestTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false); // Make the button panel transparent

        JButton approveButton = createStyledButton("Approve", new Color(0, 128, 0));
        approveButton.addActionListener(e -> handleApproveAction());
        buttonPanel.add(approveButton);

        JButton rejectButton = createStyledButton("Reject", Color.RED);
        rejectButton.addActionListener(e -> handleRejectAction());
        buttonPanel.add(rejectButton);

        JButton backButton = createStyledButton("Back", Color.GRAY);
        backButton.addActionListener(e -> cardLayout.show(mainPanel, "AdminDashboard"));
        buttonPanel.add(backButton);

        add(buttonPanel, BorderLayout.SOUTH);

        loadBuyRequests(); // Load initial data
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(new Color(20, 8, 40, 65));
            g2d.fillRect(0, 0, getWidth(), getHeight());
            g2d.dispose();
        }
    }

    private JTable createStyledTable() {
        JTable table = new JTable();
        table.setRowHeight(30);
        table.setShowGrid(true);
        table.setGridColor(Color.LIGHT_GRAY);
        table.setSelectionBackground(new Color(173, 216, 230));
        table.setSelectionForeground(Color.BLACK);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer();
        cellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        cellRenderer.setBackground(new Color(245, 245, 245));
        table.setDefaultRenderer(Object.class, cellRenderer);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 16));
        header.setBackground(new Color(60, 179, 113));
        header.setForeground(Color.WHITE);
        
        return table;
    }

    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setPreferredSize(new Dimension(150, 50));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEtchedBorder());
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(button.getBackground().darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor);
            }
        });
        return button;
    }

    private void loadBuyRequests() {
        List<BuyRequest> buyRequests = vehicleDAO.getPendingBuyRequests();
        String[] columnNames = {"Request ID", "User ID", "Vehicle Name", "Model", "Price", "Request Date", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        for (BuyRequest request : buyRequests) {
            Vehicle vehicle = vehicleDAO.getVehicleById(request.getVehicleId());
            Object[] rowData = {
                request.getRequestId(),
                request.getUserId(),
                vehicle != null ? vehicle.getMake() : "N/A",
                vehicle != null ? vehicle.getModel() : "N/A",
                vehicle != null ? vehicle.getPrice() : "N/A",
                request.getRequestDate(),
                request.getStatus()
            };
            tableModel.addRow(rowData);
        }

        buyRequestTable.setModel(tableModel);
        buyRequestTable.revalidate();
        buyRequestTable.repaint();
    }

    private void handleApproveAction() {
        int selectedRow = buyRequestTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a request to approve.");
            return;
        }

        int requestId = (int) buyRequestTable.getValueAt(selectedRow, 0);
        BuyRequest buyRequest = vehicleDAO.getBuyRequestById(requestId);
        Vehicle vehicle = vehicleDAO.getVehicleById(buyRequest.getVehicleId());

        if (vehicle == null) {
            JOptionPane.showMessageDialog(this, "Vehicle not found.");
            return;
        }

        int result = vehicleDAO.approveBuyRequest(requestId);
        if (result == 1) {
            String notificationMessage = "Your buy request for " + vehicle.getMake() + " " + vehicle.getModel() + " has been approved.";
            Notification notification = new Notification(notificationMessage, LocalDateTime.now().toString());
            NotificationManager.addNotification(buyRequest.getUserId(), notification);
            notificationsPanel.addNotification(notification);

            JOptionPane.showMessageDialog(this, "Request approved and notification sent.");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to approve the request. Please try again.");
        }

        loadBuyRequests();
    }

    private void handleRejectAction() {
        int selectedRow = buyRequestTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a request to reject.");
            return;
        }

        int requestId = (int) buyRequestTable.getValueAt(selectedRow, 0);
        BuyRequest buyRequest = vehicleDAO.getBuyRequestById(requestId);

        vehicleDAO.rejectBuyRequest(requestId);

        String notificationMessage = "Your buy request (ID: " + requestId + ") has been rejected.";
        Notification notification = new Notification(notificationMessage, LocalDateTime.now().toString());
        NotificationManager.addNotification(buyRequest.getUserId(), notification);

        // Refresh notifications panel to reflect the new notification
        notificationsPanel.addNotification(notification);
        JOptionPane.showMessageDialog(this, "Request rejected and notification sent.");
        loadBuyRequests();
    }

//    public static void main(String[] args) {
//        JFrame frame = new JFrame("Approve Buy Requests");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(800, 600);
//        frame.setLocationRelativeTo(null);
//
//        CardLayout cardLayout = new CardLayout();
//        JPanel mainPanel = new JPanel(cardLayout);
//        VehicleDAO vehicleDAO = new VehicleDAO(); // Initialize your DAO here
//        NotificationsPanel notificationsPanel = new NotificationsPanel(cardLayout, mainPanel); // Pass the card layout and main panel
//
//        ApproveBuyPanel approveBuyPanel = new ApproveBuyPanel(cardLayout, mainPanel, vehicleDAO, notificationsPanel);
//        mainPanel.add(approveBuyPanel, "ApproveBuyPanel");
//        mainPanel.add(notificationsPanel, "NotificationsPanel");
//
//        frame.add(mainPanel);
//        frame.setVisible(true);
//    }
}
