package com.vehicleinventory.AdminModule;

import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.Models.Vehicle;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddVehicle extends JPanel {
    private JTextField makeField, modelField, yearField, priceField, typeField, descriptionField, imageUrlField;
    private JCheckBox rentCheckBox, saleCheckBox;
    private VehicleDAO vehicleDAO = new VehicleDAO();
    private CardLayout cardLayout;
    private JPanel mainPanel;

    public AddVehicle(CardLayout layout, JPanel panel) {
        this.cardLayout = layout;
        this.mainPanel = panel;

        // Set the layout
        setLayout(new BorderLayout());
        setOpaque(true);

        // Header
        JPanel headerPanel = createHeaderPanel("Add New Vehicle", "Record of a vehicle's details");
        add(headerPanel, BorderLayout.NORTH);

        // Main content area
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);

        // Button panel at the bottom
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel(String title, String subtitle) {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(0, 150, 136));
        headerPanel.setPreferredSize(new Dimension(getWidth(), 150));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        subtitleLabel.setForeground(Color.WHITE);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(subtitleLabel, BorderLayout.SOUTH);

        return headerPanel;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false); // Make form panel transparent
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Form fields
        makeField = createStyledTextField();
        modelField = createStyledTextField();
        yearField = createStyledTextField();
        priceField = createStyledTextField();
        typeField = createStyledTextField(); // New field for type
        descriptionField = createStyledTextField(); // New field for description
        imageUrlField = createStyledTextField(); // New field for image URL
        rentCheckBox = new JCheckBox("Available for Rent");
        saleCheckBox = new JCheckBox("Available for Sale");

        addField(formPanel, gbc, "Make:", makeField, 0);
        addField(formPanel, gbc, "Model:", modelField, 1);
        addField(formPanel, gbc, "Year:", yearField, 2);
        addField(formPanel, gbc, "Price:", priceField, 3);
        addField(formPanel, gbc, "Type:", typeField, 4); // Add vehicle type
        addField(formPanel, gbc, "Description:", descriptionField, 5); // Add vehicle description
        addField(formPanel, gbc, "Image URL:", imageUrlField, 6); // Add vehicle image URL

        JPanel checkBoxPanel = new JPanel();
        checkBoxPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        checkBoxPanel.add(rentCheckBox);
        checkBoxPanel.add(saleCheckBox);
        gbc.gridx = 1; // Adjusting position for checkboxes
        gbc.gridy = 7; // Next row
        formPanel.add(checkBoxPanel, gbc);

        return formPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JButton addButton = createStyledButton("Add Vehicle");
        buttonPanel.add(addButton);

        JButton backButton = createStyledButton("Back");
        buttonPanel.add(backButton);

        // Action Listener for Add Button
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Vehicle vehicle = new Vehicle();
                    vehicle.setMake(makeField.getText());
                    vehicle.setModel(modelField.getText());
                    vehicle.setYear(Integer.parseInt(yearField.getText()));
                    vehicle.setPrice(Double.parseDouble(priceField.getText()));
                    vehicle.setType(typeField.getText()); // Set vehicle type
                    vehicle.setDescription(descriptionField.getText()); // Set vehicle description
                    vehicle.setImageUrl(imageUrlField.getText()); // Set vehicle image URL
                    vehicle.setAvailableForRent(rentCheckBox.isSelected());
                    vehicle.setAvailableForSale(saleCheckBox.isSelected());

                    vehicleDAO.addVehicle(vehicle);
                    JOptionPane.showMessageDialog(null, "Vehicle added successfully!");

                    // Clear the form fields
                    clearFormFields();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid data.");
                }
            }
        });

        // Action Listener for Back Button
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Navigate back to the AdminDashboard
                mainPanel.add(new AdminDashboard(cardLayout, mainPanel), "AdminDashboard");
                cardLayout.show(mainPanel, "AdminDashboard");
            }
        });

        return buttonPanel;
    }

    private JTextField createStyledTextField() {
        JTextField textField = new JTextField(25);
        textField.setBorder(BorderFactory.createLineBorder(new Color(0, 150, 136)));
        textField.setFont(new Font("Arial", Font.PLAIN, 16));
        textField.setPreferredSize(new Dimension(250, 35));
        return textField;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0, 150, 136));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(160, 45));
        return button;
    }

    private void addField(JPanel panel, GridBagConstraints gbc, String labelText, JTextField textField, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        panel.add(label, gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(textField, gbc); // Add the text field next to the label
    }

    private void clearFormFields() {
        makeField.setText("");
        modelField.setText("");
        yearField.setText("");
        priceField.setText("");
        typeField.setText(""); // Clear vehicle type
        descriptionField.setText(""); // Clear vehicle description
        imageUrlField.setText(""); // Clear vehicle image URL
        rentCheckBox.setSelected(false);
        saleCheckBox.setSelected(false);
    }
}
