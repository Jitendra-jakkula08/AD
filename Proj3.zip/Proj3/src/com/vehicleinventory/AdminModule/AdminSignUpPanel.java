package com.vehicleinventory.AdminModule;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminSignUpPanel extends JPanel {
    public AdminSignUpPanel(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());

        // Create sign-up form components
        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField(15);

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(15);

        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        JPasswordField confirmPasswordField = new JPasswordField(15);

        JButton signUpButton = new JButton("Sign Up");

        // Handle sign-up button click
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle admin sign-up logic here
                // For now, we'll just switch to the admin login page after sign-up
                cardLayout.show(mainPanel, "AdminLogin");
            }
        });

        // Add components to the panel
        JPanel formPanel = new JPanel(new GridLayout(4, 2));
        formPanel.add(usernameLabel);
        formPanel.add(usernameField);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);
        formPanel.add(confirmPasswordLabel);
        formPanel.add(confirmPasswordField);
        formPanel.add(signUpButton);

        add(formPanel, BorderLayout.CENTER);
    }
}
