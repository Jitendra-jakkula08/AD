package com.vehicleinventory.AdminModule;

import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.Models.Vehicle;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UpdateVehicle extends JPanel {
    private JTextField idField, makeField, brandField, modelField, yearField, priceField;
    private JCheckBox rentCheckBox, saleCheckBox;
    private VehicleDAO vehicleDAO = new VehicleDAO();

    public UpdateVehicle() {
        setLayout(new GridLayout(8, 2));

        // Initialize components
        idField = new JTextField(15);
        makeField = new JTextField(15); // Change here
        brandField = new JTextField(15);
        modelField = new JTextField(15);
        yearField = new JTextField(15);
        priceField = new JTextField(15);
        rentCheckBox = new JCheckBox("Available for Rent");
        saleCheckBox = new JCheckBox("Available for Sale");

        // Add components to panel
        add(new JLabel("ID:"));
        add(idField);
        add(new JLabel("Make:")); // Change here
        add(makeField); // Change here
        add(new JLabel("Brand:"));
        add(brandField);
        add(new JLabel("Model:"));
        add(modelField);
        add(new JLabel("Year:"));
        add(yearField);
        add(new JLabel("Price:"));
        add(priceField);
        add(rentCheckBox);
        add(saleCheckBox);

        JButton updateButton = new JButton("Update Vehicle");
        add(updateButton);

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Vehicle vehicle = new Vehicle();
                    vehicle.setId(Integer.parseInt(idField.getText()));
                    vehicle.setMake(makeField.getText()); // Change here
                    vehicle.setModel(modelField.getText());
                    vehicle.setYear(Integer.parseInt(yearField.getText()));
                    vehicle.setPrice(Double.parseDouble(priceField.getText()));
                    vehicle.setAvailableForRent(rentCheckBox.isSelected());
                    vehicle.setAvailableForSale(saleCheckBox.isSelected());

                    vehicleDAO.updateVehicle(vehicle);
                    JOptionPane.showMessageDialog(null, "Vehicle updated successfully!");

                    // Clear the form fields
                    idField.setText("");
                    makeField.setText(""); // Change here
                    brandField.setText("");
                    modelField.setText("");
                    yearField.setText("");
                    priceField.setText("");
                    rentCheckBox.setSelected(false);
                    saleCheckBox.setSelected(false);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid data.");
                }
            }
        });
    }
}
