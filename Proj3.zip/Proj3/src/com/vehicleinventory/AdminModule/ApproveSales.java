package com.vehicleinventory.AdminModule;

import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.Models.SaleRequest;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ApproveSales extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;

    public ApproveSales(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());

        // Create the table model and table
        String[] columnNames = {"Request ID", "User ID", "Vehicle Description", "Image", "Status", "Approve", "Reject"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column >= 5) { // Approve and Reject columns
                    return JButton.class; // Treat as buttons
                }
                return String.class; // Other columns are strings
            }
        };
        table.setFillsViewportHeight(true);
        table.setRowHeight(30); // Set row height for better visibility
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Load pending sale requests from the database
        loadPendingSaleRequests();

        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); // Align buttons to the left
        add(buttonPanel, BorderLayout.SOUTH);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(70, 130, 180)); // Steel Blue color
        refreshButton.setForeground(Color.WHITE);
        refreshButton.addActionListener(e -> loadPendingSaleRequests());
        buttonPanel.add(refreshButton);

        JButton backButton = new JButton("Back");
        backButton.setBackground(new Color(220, 20, 60)); // Crimson color for back button
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "AdminDashboard"); // Navigate back to Admin Dashboard
            }
        });
        buttonPanel.add(backButton);
        
        // Set custom cell renderer for button columns
        table.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
        table.getColumnModel().getColumn(6).setCellRenderer(new ButtonRenderer());

        // Mouse listener for button actions
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int column = table.columnAtPoint(e.getPoint());
                if (row >= 0 && (column == 5 || column == 6)) { // Check if Approve or Reject clicked
                    int requestId = (int) tableModel.getValueAt(row, 0); // Get request ID
                    if (column == 5) {
                        approveSaleRequest(requestId); // Approve button action
                    } else if (column == 6) {
                        rejectSaleRequest(requestId); // Reject button action
                    }
                }
            }
        });
    }

    private void loadPendingSaleRequests() {
        // Clear existing data
        tableModel.setRowCount(0);

        VehicleDAO vehicleDAO = new VehicleDAO();
        List<SaleRequest> pendingRequests = vehicleDAO.getPendingSaleRequests(); // Ensure this method exists in VehicleDAO

        for (SaleRequest request : pendingRequests) {
            Object[] rowData = {
                request.getRequestId(),
                request.getUser().getId(),
                request.getVehicleDescription(),
                request.getImageUrl(), // Handle image displaying appropriately
                request.getStatus(),
                "Approve", // Button label
                "Reject"   // Button label
            };
            tableModel.addRow(rowData);
        }
    }

    private void approveSaleRequest(int requestId) {
        VehicleDAO vehicleDAO = new VehicleDAO();
        boolean success = vehicleDAO.approveSellRequest(requestId); // Ensure this method exists
        if (success) {
            JOptionPane.showMessageDialog(this, "Sell request approved.");
            loadPendingSaleRequests(); // Refresh the pending sale requests to show the updated status
        } else {
            JOptionPane.showMessageDialog(this, "Failed to approve sell request.");
        }
    }

    private void rejectSaleRequest(int requestId) {
        VehicleDAO vehicleDAO = new VehicleDAO();
        boolean success = vehicleDAO.rejectSellRequest(requestId); // Ensure this method exists
        if (success) {
            JOptionPane.showMessageDialog(this, "Sell request rejected.");
            loadPendingSaleRequests(); // Refresh the table
        } else {
            JOptionPane.showMessageDialog(this, "Failed to reject sell request.");
        }
    }

    // Custom renderer for button cells
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true); // Make background color visible
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            setText(value != null ? value.toString() : "");
            setBackground(isSelected ? Color.LIGHT_GRAY : Color.WHITE);
            setForeground(Color.BLUE); // Change the text color
            return this;
        }
    }
}
