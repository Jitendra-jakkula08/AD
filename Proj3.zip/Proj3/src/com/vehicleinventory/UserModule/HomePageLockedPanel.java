package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;

public class HomePageLockedPanel extends JPanel {
    private Image backgroundImage;

    public HomePageLockedPanel(CardLayout cardLayout, JPanel mainPanel) {
        // Load the background image from resources
        backgroundImage = new ImageIcon(getClass().getResource("/resources/home1.jpeg")).getImage();

        setLayout(new BorderLayout());

        // Toolbar with navigation buttons
        JToolBar toolbar = new JToolBar();
        toolbar.setFloatable(false);
        toolbar.setOpaque(false);
        toolbar.setLayout(new FlowLayout(FlowLayout.CENTER));

        Dimension buttonSize = new Dimension(120, 70);

        // Create and add buttons to the toolbar
        JButton viewProfileButton = createButton("View Profile", "/resources/profile.jpg", buttonSize);
        toolbar.add(viewProfileButton);

        JButton rentButton = createButton("Rent", "/resources/rent.jpg", buttonSize);
        toolbar.add(rentButton);

        JButton buyButton = createButton("Buy", "/resources/buy.png", buttonSize);
        toolbar.add(buyButton);

        JButton sellButton = createButton("Sell", "/resources/sell.png", buttonSize);
        toolbar.add(sellButton);

        // Add Notifications button
        JButton notificationsButton = createButton("Notifications", "/resources/notification.png", buttonSize);
        toolbar.add(notificationsButton);

        // Replace Logout button with Login button
        JButton loginButton = createButton("Login", "/resources/home.jpg", buttonSize);
        toolbar.add(loginButton);

        add(toolbar, BorderLayout.NORTH);

        // Content area with a welcome message
        JTextArea contentArea = new JTextArea("Welcome to the Vehicle-Hub!\n\n"
                + "Your one-stop destination for all your vehicle needs!\n\n"
                + "To access more features, please login or sign up!");

        contentArea.setOpaque(false);
        contentArea.setEditable(false);
        contentArea.setFont(new Font("Verdana", Font.PLAIN, 16));
        contentArea.setForeground(Color.DARK_GRAY);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);

        add(contentArea, BorderLayout.CENTER);

        // Disable buttons with a "Login to use" message
        viewProfileButton.addActionListener(e -> showLoginMessage());
        rentButton.addActionListener(e -> showLoginMessage());
        buyButton.addActionListener(e -> showLoginMessage());
        sellButton.addActionListener(e -> showLoginMessage());
        notificationsButton.addActionListener(e -> showLoginMessage());

        // Login button navigates to the login page
        loginButton.addActionListener(e -> cardLayout.show(mainPanel, "UserLogin"));
    }

    private JButton createButton(String text, String iconPath, Dimension size) {
        JButton button = new JButton(text);
        button.setPreferredSize(size);

        ImageIcon icon = new ImageIcon(getClass().getResource(iconPath));
        Image img = icon.getImage().getScaledInstance((int) size.getWidth() - 20, (int) size.getHeight() - 40, Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(img));

        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setVerticalTextPosition(SwingConstants.BOTTOM);

        return button;
    }

    private void showLoginMessage() {
        JOptionPane.showMessageDialog(this, "Please Login to Continue..", "Access Denied", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}
