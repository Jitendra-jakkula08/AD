package com.vehicleinventory.UserModule;
//
import com.vehicleinventory.Database.UserDAO;
import com.vehicleinventory.Models.User;
import com.vehicleinventory.Models.UserSession;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

// Interface for login success listener
interface LoginSuccessListener {
    void onLoginSuccess(int userId);
}

public class UserLoginPanel extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private List<LoginSuccessListener> loginSuccessListeners;

    public UserLoginPanel(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());
        setBackground(Color.decode("#f7f7f7")); // Light background for a modern look

        // Left panel for the welcome message
        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setBackground(Color.decode("#2E7D32")); // Green color for the left section
        leftPanel.setPreferredSize(new Dimension(400, 0));
        GridBagConstraints gbcLeft = new GridBagConstraints();
        gbcLeft.insets = new Insets(20, 20, 20, 20);
        gbcLeft.anchor = GridBagConstraints.CENTER;

        // Welcome label with modern font
        JLabel welcomeLabel = new JLabel("Welcome Back!");
        welcomeLabel.setFont(new Font("Segoe Print", Font.BOLD, 36)); // Changed font to Segoe Print
        welcomeLabel.setForeground(Color.WHITE);
        gbcLeft.gridx = 0;
        gbcLeft.gridy = 0;
        leftPanel.add(welcomeLabel, gbcLeft);

        // Subtext label with lighter font
        JLabel subTextLabel = new JLabel("Log in to continue managing your vehicles.");
        subTextLabel.setFont(new Font("Segoe Print", Font.PLAIN, 16)); // Changed font to Segoe Print
        subTextLabel.setForeground(Color.WHITE);
        gbcLeft.gridy = 1;
        leftPanel.add(subTextLabel, gbcLeft);

        // Sign Up button with modern design
        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setFont(new Font("Segoe Print", Font.BOLD, 16)); // Changed font to Segoe Print
        signUpButton.setBackground(Color.WHITE);
        signUpButton.setForeground(Color.decode("#2E7D32"));
        signUpButton.setBorder(BorderFactory.createLineBorder(Color.decode("#2E7D32")));
        signUpButton.setFocusPainted(false);
        signUpButton.setPreferredSize(new Dimension(200, 50)); // Increased button size
        gbcLeft.gridy = 2;
        leftPanel.add(signUpButton, gbcLeft);

        add(leftPanel, BorderLayout.WEST);

        // Right panel for the login form
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50)); // Add padding
        GridBagConstraints gbcRight = new GridBagConstraints();
        gbcRight.insets = new Insets(10, 10, 20, 10);
        gbcRight.anchor = GridBagConstraints.CENTER;
        gbcRight.fill = GridBagConstraints.HORIZONTAL;

        // Login label with modern font
        JLabel loginLabel = new JLabel("Log In");
        loginLabel.setFont(new Font("Segoe Print", Font.BOLD, 30)); // Changed font to Segoe Print
        loginLabel.setForeground(Color.decode("#2E7D32"));
        gbcRight.gridx = 0;
        gbcRight.gridy = 0;
        gbcRight.gridwidth = 2;
        rightPanel.add(loginLabel, gbcRight);

        // Username label and field with more padding and custom font
       // Username label and field with more compact padding and custom font
JLabel usernameLabel = new JLabel("Username");
usernameLabel.setFont(new Font("Segoe Print", Font.PLAIN, 14)); // Changed font to Segoe Print
usernameLabel.setForeground(Color.decode("#000000"));
gbcRight.gridx = 0;
gbcRight.gridy = 1;
// Reduce padding for label
gbcRight.insets = new Insets(5, 10, 5, 10); 
rightPanel.add(usernameLabel, gbcRight);

usernameField = new JTextField(20);
usernameField.setFont(new Font("Segoe Print", Font.PLAIN, 14)); // Changed font to Segoe Print
usernameField.setPreferredSize(new Dimension(250, 35));
usernameField.setBorder(BorderFactory.createLineBorder(Color.decode("#000000")));
gbcRight.gridy = 2;
// Reduce padding between the username label and field
gbcRight.insets = new Insets(2, 10, 10, 10); 
rightPanel.add(usernameField, gbcRight);

// Password label and field with compact padding
JLabel passwordLabel = new JLabel("Password");
passwordLabel.setFont(new Font("Segoe Print", Font.PLAIN, 14)); // Changed font to Segoe Print
passwordLabel.setForeground(Color.decode("#000000"));
gbcRight.gridy = 3;
// Reduce padding for label
gbcRight.insets = new Insets(5, 10, 5, 10);
rightPanel.add(passwordLabel, gbcRight);

passwordField = new JPasswordField(20);
passwordField.setFont(new Font("Segoe Print", Font.PLAIN, 14)); // Changed font to Segoe Print
passwordField.setPreferredSize(new Dimension(250, 35));
passwordField.setBorder(BorderFactory.createLineBorder(Color.decode("#000000")));
gbcRight.gridy = 4;
// Reduce padding between the password label and field
gbcRight.insets = new Insets(2, 10, 20, 10);
rightPanel.add(passwordField, gbcRight);


        // Log In button with modern design and increased size
        JButton loginButton = new JButton("Log In");
        loginButton.setFont(new Font("Segoe Print", Font.BOLD, 20)); // Changed font to Segoe Print
        loginButton.setBackground(Color.decode("#2E7D32"));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBorder(BorderFactory.createLineBorder(Color.decode("#2E7D32")));
        loginButton.setFocusPainted(false);
        loginButton.setPreferredSize(new Dimension(200, 50)); // Increased button size
        gbcRight.gridy = 5;
        gbcRight.gridwidth = 2;
        gbcRight.insets = new Insets(30, 0, 0, 0);
        rightPanel.add(loginButton, gbcRight);

        add(rightPanel, BorderLayout.CENTER);

        // Initialize listeners list
        loginSuccessListeners = new ArrayList<>();

        // Sign Up Button Action Listener
        signUpButton.addActionListener(e -> cardLayout.show(mainPanel, "UserSignUp"));

        // Log In Button Action Listener
        loginButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(UserLoginPanel.this, "Username and password cannot be empty.");
                return;
            }

            UserDAO userDAO = new UserDAO();
            User user = userDAO.getUserByUsername(username);

            if (user != null) {
                if (user.getPassword().equals(password)) {
                    UserSession userSession = UserSession.getInstance();
                    userSession.setUserId(user.getId());
                    userSession.setUsername(user.getUsername());

                    for (LoginSuccessListener listener : loginSuccessListeners) {
                        listener.onLoginSuccess(user.getId());
                    }

                    JOptionPane.showMessageDialog(UserLoginPanel.this, "Login successful.");
                    cardLayout.show(mainPanel, "HomePage");
                } else {
                    JOptionPane.showMessageDialog(UserLoginPanel.this, "Invalid username or password.");
                }
            } else {
                JOptionPane.showMessageDialog(UserLoginPanel.this, "Invalid username or password.");
            }
        });
    }

    // Method to add a login success listener
    public void addLoginSuccessListener(LoginSuccessListener listener) {
        this.loginSuccessListeners.add(listener);
    }

    // New method to return the logged-in user's ID
    public int getLoggedInUserId() {
        return UserSession.getInstance().getUserId();
    }

    // Main method to launch the application
    public static void main(String[] args) {
        // Set up the JFrame
        JFrame frame = new JFrame("Vehicle Inventory - Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        
        // Create CardLayout and main panel
        CardLayout cardLayout = new CardLayout();
        JPanel mainPanel = new JPanel(cardLayout);
        
        // Create UserLoginPanel and add it to the main panel
        UserLoginPanel loginPanel = new UserLoginPanel(cardLayout, mainPanel);
        mainPanel.add(loginPanel, "User Login");

        // Set the CardLayout to the login screen initially
        cardLayout.show(mainPanel, "User Login");

        // Add the main panel to the frame and set it visible
        frame.add(mainPanel);
        frame.setVisible(true);
    }
}
