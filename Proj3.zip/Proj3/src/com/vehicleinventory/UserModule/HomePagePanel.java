package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;

public class HomePagePanel extends JPanel {
    private Image backgroundImage;

    public HomePagePanel(CardLayout cardLayout, JPanel mainPanel) {
        // Load the background image from resources
        backgroundImage = new ImageIcon(getClass().getResource("/resources/home1.jpeg")).getImage();

        setLayout(new BorderLayout());

        // Toolbar with navigation buttons
        JToolBar toolbar = new JToolBar();
        toolbar.setFloatable(false);
        toolbar.setOpaque(false);
        toolbar.setLayout(new FlowLayout(FlowLayout.CENTER));

        Dimension buttonSize = new Dimension(120, 70); // Set button size here

        // Create and add buttons to the toolbar
        JButton viewProfileButton = createButton("View Profile", "/resources/profile.jpg", buttonSize);
        toolbar.add(viewProfileButton);

//        JButton settingsButton = createButton("Settings", "/resources/setting.png", buttonSize);
//        toolbar.add(settingsButton);

        JButton rentButton = createButton("Rent", "/resources/rent.jpg", buttonSize);
        toolbar.add(rentButton);

        JButton buyButton = createButton("Buy", "/resources/buy.png", buttonSize);
        toolbar.add(buyButton);

        JButton sellButton = createButton("Sell", "/resources/sell.png", buttonSize);
        toolbar.add(sellButton);

        // Add Notifications button
        JButton notificationsButton = createButton("Notifications", "/resources/notification.png", buttonSize);
        notificationsButton.addActionListener(e -> {
            NotificationsPanel notificationsPanel = new NotificationsPanel(cardLayout, mainPanel);
            mainPanel.add(notificationsPanel, "NotificationsPanel");
            cardLayout.show(mainPanel, "NotificationsPanel");
        });
        toolbar.add(notificationsButton); // Add notifications button

        JButton logoutButton = createButton("Logout", "/resources/home.jpg", buttonSize);
        toolbar.add(logoutButton);

        add(toolbar, BorderLayout.NORTH);

        // Content area with a welcome message
        JTextArea contentArea = new JTextArea("Welcome to the Vehicle-Hub!\n\n"
                + "Your one-stop destination for all your vehicle needs!\n\n"
                + "Here you can:\n"
                + "- Rent vehicles easily\n"
                + "- Buy pre-owned vehicles\n"
                + "- Sell your vehicles\n"
                + "Choose an option from the toolbar above to get started!");

        contentArea.setOpaque(false);
        contentArea.setEditable(false);
        contentArea.setFont(new Font("Verdana", Font.PLAIN, 16));
        contentArea.setForeground(Color.DARK_GRAY);
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);

        add(contentArea, BorderLayout.CENTER);

        // Event handling for navigation
        viewProfileButton.addActionListener(e -> cardLayout.show(mainPanel, "ProfilePagePanel"));
//        settingsButton.addActionListener(e -> cardLayout.show(mainPanel, "SettingsPagePanel"));
        rentButton.addActionListener(e -> cardLayout.show(mainPanel, "RentPagePanel"));
        buyButton.addActionListener(e -> {
            BuyVehiclePanel buyVehiclePanel = new BuyVehiclePanel(cardLayout, mainPanel);
            mainPanel.add(buyVehiclePanel, "BuyVehiclePanel");
            cardLayout.show(mainPanel, "BuyVehiclePanel");
        });
        sellButton.addActionListener(e -> cardLayout.show(mainPanel, "SellPagePanel"));
        logoutButton.addActionListener(e -> {
            // Handle logout
            cardLayout.show(mainPanel, "UserLogin");
        });
    }

    private JButton createButton(String text, String iconPath, Dimension size) {
        JButton button = new JButton(text);
        button.setPreferredSize(size);

        ImageIcon icon = new ImageIcon(getClass().getResource(iconPath));
        Image img = icon.getImage().getScaledInstance((int) size.getWidth() - 20, (int) size.getHeight() - 40, Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(img));

        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setVerticalTextPosition(SwingConstants.BOTTOM);

        return button;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}
