package com.vehicleinventory.UserModule;

import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.Models.Vehicle;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ViewVehicles extends JPanel {
    private VehicleDAO vehicleDAO = new VehicleDAO();

    public ViewVehicles() {
        setLayout(new BorderLayout());

        // Get the list of vehicles
        List<Vehicle> vehicles = vehicleDAO.getAllVehicles();

        // Create a panel to display vehicle information
        JPanel vehiclePanel = new JPanel();
        vehiclePanel.setLayout(new GridLayout(0, 1));

        for (Vehicle vehicle : vehicles) {
            JPanel vehicleInfo = new JPanel();
            vehicleInfo.setLayout(new GridLayout(1, 5));
            vehicleInfo.add(new JLabel("Type: " + vehicle.getType()));
            vehicleInfo.add(new JLabel("Make: " + vehicle.getMake())); // Corrected from getBrand() to getMake()
            vehicleInfo.add(new JLabel("Model: " + vehicle.getModel()));
            vehicleInfo.add(new JLabel("Year: " + vehicle.getYear()));
            vehicleInfo.add(new JLabel("Price: $" + vehicle.getPrice()));
            vehiclePanel.add(vehicleInfo);
        }

        JScrollPane scrollPane = new JScrollPane(vehiclePanel);
        add(scrollPane, BorderLayout.CENTER);
    }
}
