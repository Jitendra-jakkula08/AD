package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;

public class SettingsPagePanel extends JPanel {
    public SettingsPagePanel(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());

        // Header with navigation buttons
        JPanel headerPanel = new JPanel();
        JButton backButton = new JButton("Back");
        headerPanel.add(backButton);
        add(headerPanel, BorderLayout.NORTH);

        // Main content area
        JTextArea settingsContent = new JTextArea("Settings");
        settingsContent.setEditable(false);
        add(settingsContent, BorderLayout.CENTER);

        // Back button action
        backButton.addActionListener(e -> {
            cardLayout.show(mainPanel, "HomePage");
        });
    }
}
