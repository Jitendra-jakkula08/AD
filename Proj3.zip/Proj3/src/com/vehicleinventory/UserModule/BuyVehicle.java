package com.vehicleinventory.UserModule;

import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.Models.Vehicle;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BuyVehicle extends JPanel {
    private JTextField vehicleIdField;
    private VehicleDAO vehicleDAO = new VehicleDAO();

    public BuyVehicle() {
        setLayout(new GridLayout(2, 2));

        // Initialize components
        vehicleIdField = new JTextField(15);
        JButton buyButton = new JButton("Buy Vehicle");

        // Add components to panel
        add(new JLabel("Vehicle ID:"));
        add(vehicleIdField);
        add(buyButton);

        buyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int vehicleId = Integer.parseInt(vehicleIdField.getText());
                    Vehicle vehicle = vehicleDAO.getVehicleById(vehicleId);

                    if (vehicle != null && vehicle.isAvailableForSale()) {
//                        vehicleDAO.deleteVehicle(vehicleId);
                        JOptionPane.showMessageDialog(null, "Vehicle bought successfully!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Vehicle not available for sale.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Vehicle ID.");
                }
            }
        });
        
    }
    
}
