package com.vehicleinventory.UserModule;

import com.vehicleinventory.Database.RentRequestDAO;
import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.Models.Vehicle;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class RentPagePanel extends JPanel {
    private CardLayout cardLayout;
    private JPanel parentPanel;
    private VehicleDAO vehicleDAO;
    private RentRequestDAO rentRequestDAO;
    private Image backgroundImage;

    public RentPagePanel(CardLayout cardLayout, JPanel parentPanel) {
        this.cardLayout = cardLayout;
        this.parentPanel = parentPanel;
        this.vehicleDAO = new VehicleDAO();
        this.rentRequestDAO = new RentRequestDAO();

        // Load the background image
        try {
            backgroundImage = ImageIO.read(getClass().getClassLoader().getResourceAsStream("resources/inventory.jpeg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        setLayout(new BorderLayout());
        setOpaque(false);

        JPanel vehiclesPanel = new JPanel(new GridBagLayout());
        vehiclesPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        List<Vehicle> vehicles = vehicleDAO.getAvailableVehiclesForRent();
        int row = 0;

        for (Vehicle vehicle : vehicles) {
            JPanel vehiclePanel = createVehiclePanel(vehicle);
            gbc.gridx = 0;
            gbc.gridy = row++;
            vehiclesPanel.add(vehiclePanel, gbc);
        }

        JScrollPane scrollPane = new JScrollPane(vehiclesPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);

        JButton backButton = createStyledButton("Back", Color.RED);
        backButton.addActionListener(e -> cardLayout.show(parentPanel, "HomePage"));
        add(backButton, BorderLayout.SOUTH);

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(240, 240, 240, 200));
        JLabel headerLabel = new JLabel("Available Vehicles for Rent");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

    private JPanel createVehiclePanel(Vehicle vehicle) {
        JPanel vehiclePanel = new JPanel(new BorderLayout());
        vehiclePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        vehiclePanel.setBackground(new Color(255, 255, 255, 150));
        vehiclePanel.setPreferredSize(new Dimension(250, 150));

        JLabel vehicleLabel = new JLabel(vehicle.getMake() + " " + vehicle.getModel());
        vehicleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        vehiclePanel.add(vehicleLabel, BorderLayout.NORTH);

        JLabel priceLabel = new JLabel("Price: $" + vehicle.getPrice());
        priceLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        vehiclePanel.add(priceLabel, BorderLayout.CENTER);

        JButton rentButton = createStyledButton("Rent", new Color(0, 128, 0));
        rentButton.addActionListener(e -> showRentForm(vehicle));
        vehiclePanel.add(rentButton, BorderLayout.SOUTH);

        return vehiclePanel;
    }

    private void showRentForm(Vehicle vehicle) {
    JTextField usernameField = new JTextField(20);
    JTextField rentalDurationField = new JTextField(20);
    JTextArea additionalNotesArea = new JTextArea(3, 20);

    JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
    formPanel.add(new JLabel("Username:"));
    formPanel.add(usernameField);
    formPanel.add(new JLabel("Rental Duration (days):"));
    formPanel.add(rentalDurationField);
    formPanel.add(new JLabel("Additional Notes:"));
    formPanel.add(new JScrollPane(additionalNotesArea));

    int result = JOptionPane.showConfirmDialog(this, formPanel, "Rent Vehicle", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
        String username = usernameField.getText();
        int rentalDuration = Integer.parseInt(rentalDurationField.getText());
        String additionalNotes = additionalNotesArea.getText();

        int requestId = rentRequestDAO.createRentRequest(vehicle.getId());

        if (requestId > 0) { // Check if request ID is valid
            rentRequestDAO.createRentalDetail(requestId, username, rentalDuration, additionalNotes);
            JOptionPane.showMessageDialog(this, "Rent request submitted. Waiting for admin approval.");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to create rent request.");
        }
    }
    
    
}



    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setPreferredSize(new Dimension(150, 50));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEtchedBorder());
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(button.getBackground().darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor);
            }
        });
        return button;
    }
    
    public static void main(String[] args) {
        // Create the frame
        JFrame frame = new JFrame("Rent Page Panel Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        // Create the CardLayout and parent panel
        CardLayout cardLayout = new CardLayout();
        JPanel parentPanel = new JPanel(cardLayout);

        // Create an instance of RentPagePanel and add it to the parent panel
        RentPagePanel rentPagePanel = new RentPagePanel(cardLayout, parentPanel);
        parentPanel.add(rentPagePanel, "RentPage");

        // Add the parent panel to the frame
        frame.add(parentPanel);

        // Show the RentPagePanel
        cardLayout.show(parentPanel, "RentPage");

        // Make the frame visible
        frame.setVisible(true);
    }
}
