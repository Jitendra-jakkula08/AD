// File: src/com/vehicleinventory/UserModule/SignUpFrame.java

package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignUpFrame extends JFrame {
    public SignUpFrame() {
        setTitle("Sign Up");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(5, 2));

        // Create and add components
        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();
        JButton signUpButton = new JButton("Sign Up");
        
        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(emailLabel);
        add(emailField);
        add(new JLabel()); // Empty cell
        add(signUpButton);

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle sign-up logic here
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String email = emailField.getText();
                
                // Example: Create a user object and add it to the database
                // User user = new User(username, password, email);
                // UserDAO userDAO = new UserDAO();
                // userDAO.addUser(user);

                // Show confirmation message or handle post-sign-up actions
                JOptionPane.showMessageDialog(SignUpFrame.this, "Sign-Up Successful!");
                dispose(); // Close the sign-up window
            }
        });
    }
}
