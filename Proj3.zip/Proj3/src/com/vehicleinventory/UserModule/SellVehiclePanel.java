//package com.vehicleinventory.UserModule;
//
//import com.vehicleinventory.Database.VehicleDAO;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//public class SellVehiclePanel extends JPanel {
//    private JTextField vehicleDescriptionField;
//    private JTextField vehicleImageUrlField;
//
//    public SellVehiclePanel(JPanel mainPanel) {
//        setLayout(new BorderLayout());
//
//        // Header
//        JLabel headerLabel = new JLabel("Sell Vehicle", SwingConstants.CENTER);
//        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
//        add(headerLabel, BorderLayout.NORTH);
//
//        // Form panel for input fields
//        JPanel formPanel = new JPanel(new GridLayout(3, 2)); // 3 rows, 2 columns
//
//        // Vehicle description input
//        formPanel.add(new JLabel("Vehicle Description:"));
//        vehicleDescriptionField = new JTextField();
//        formPanel.add(vehicleDescriptionField);
//
//        // Vehicle image URL input
//        formPanel.add(new JLabel("Image URL:"));
//        vehicleImageUrlField = new JTextField();
//        formPanel.add(vehicleImageUrlField);
//
//        // Sell button
//        JButton sellButton = new JButton("Sell Vehicle");
//        sellButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                String description = vehicleDescriptionField.getText().trim();
//                String imageUrl = vehicleImageUrlField.getText().trim();
//
//                // Validate inputs
//                if (description.isEmpty() || imageUrl.isEmpty()) {
//                    JOptionPane.showMessageDialog(SellVehiclePanel.this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
//                    return; // Exit the action listener if validation fails
//                }
//
//                // Here, you would add the code to insert the sale request into the database
//                VehicleDAO vehicleDAO = new VehicleDAO();
//                int currentUserId = 1; // Replace with the actual current user ID from the session
//                boolean success = vehicleDAO.createSellRequest(currentUserId, description, imageUrl);
//
//                if (success) {
//                    JOptionPane.showMessageDialog(SellVehiclePanel.this, "Sell request submitted. Waiting for admin approval.");
//                    // Clear the fields after submission
//                    vehicleDescriptionField.setText("");
//                    vehicleImageUrlField.setText("");
//                } else {
//                    JOptionPane.showMessageDialog(SellVehiclePanel.this, "Error submitting request. Please try again later.", "Submission Error", JOptionPane.ERROR_MESSAGE);
//                }
//            }
//        });
//        formPanel.add(sellButton);
//        
//        // Add form panel to the center of the SellVehiclePanel
//        add(formPanel, BorderLayout.CENTER);
//
//        // Back button
//        JButton backButton = new JButton("Back");
//        add(backButton, BorderLayout.SOUTH);
//
//        // Action Listener for back button
//        backButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                CardLayout cl = (CardLayout) (mainPanel.getLayout());
//                cl.show(mainPanel, "HomePage");
//            }
//        });
//    }
//}
