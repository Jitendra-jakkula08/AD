package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewVehiclesPanel extends JPanel {
    public ViewVehiclesPanel(JPanel mainPanel) {
        setLayout(new BorderLayout());

        // Content for View Vehicles
        add(new JLabel("View Vehicles", SwingConstants.CENTER), BorderLayout.CENTER);

        // Back button
        JButton backButton = new JButton("Back");
        add(backButton, BorderLayout.SOUTH);

        // Action Listener for back button
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cl = (CardLayout) (mainPanel.getLayout());
                cl.show(mainPanel, "HomePage");
            }
        });
    }
}
