//package com.vehicleinventory.UserModule;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//public class SellPanel extends JPanel {
//    public SellPanel(CardLayout cardLayout, JPanel mainPanel) {
//        setLayout(new BorderLayout());
//
//        JLabel sellLabel = new JLabel("Sell a Vehicle");
//        sellLabel.setHorizontalAlignment(SwingConstants.CENTER);
//        add(sellLabel, BorderLayout.CENTER);
//
//        JButton backButton = new JButton("Back");
//        add(backButton, BorderLayout.SOUTH);
//
//        backButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                cardLayout.show(mainPanel, "HomePage");
//            }
//        });
//    }
//}
