package com.vehicleinventory.UserModule;

import com.vehicleinventory.Database.VehicleDAO; // Ensure this import is present
import javax.swing.*;
import java.awt.*;

public class BuyPagePanel extends JPanel {
    private int currentUserId;   // Add a field for user ID
    private int selectedVehicleId; // Add a field for vehicle ID

    public BuyPagePanel(CardLayout cardLayout, JPanel mainPanel, int currentUserId, int selectedVehicleId) {
        this.currentUserId = currentUserId; // Initialize user ID
        this.selectedVehicleId = selectedVehicleId; // Initialize vehicle ID

        setLayout(new BorderLayout());

        // Header with navigation buttons
        JPanel headerPanel = new JPanel();
        JButton backButton = new JButton("Back");
        headerPanel.add(backButton);
        add(headerPanel, BorderLayout.NORTH);

        // Main content area
        JTextArea buyContent = new JTextArea("Buy Vehicles");
        buyContent.setEditable(false);
        add(buyContent, BorderLayout.CENTER);

        // Buy button
        JButton buyButton = new JButton("Buy");
        buyButton.addActionListener(e -> {
            VehicleDAO vehicleDAO = new VehicleDAO();
            vehicleDAO.createBuyRequest(currentUserId, selectedVehicleId);

            JOptionPane.showMessageDialog(this, "Buy request submitted. Waiting for admin approval.");
        });
        add(buyButton, BorderLayout.SOUTH); // Adding button to the south position

        // Back button action
        backButton.addActionListener(e -> {
            cardLayout.show(mainPanel, "HomePage");
        });
    }
}
