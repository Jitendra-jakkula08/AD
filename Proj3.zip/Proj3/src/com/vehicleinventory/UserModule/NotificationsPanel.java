package com.vehicleinventory.UserModule;

import com.vehicleinventory.Models.Notification;
import java.time.LocalDateTime;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class NotificationsPanel extends JPanel {
    private JPanel notificationsPanel;
    private List<Notification> notifications;
    private CardLayout cardLayout; // Add CardLayout reference
    private JPanel mainPanel; // Add mainPanel reference

    // Updated constructor
    public NotificationsPanel(CardLayout cardLayout, JPanel mainPanel) {
        System.out.println("NotificationsPanel initialized.");
        this.cardLayout = cardLayout; // Initialize CardLayout
        this.mainPanel = mainPanel; // Initialize mainPanel
        setLayout(new BorderLayout());
        notifications = new ArrayList<>();

        JLabel titleLabel = new JLabel("Notifications", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        notificationsPanel = new JPanel();
        notificationsPanel.setLayout(new BoxLayout(notificationsPanel, BoxLayout.Y_AXIS));
        notificationsPanel.setBackground(Color.LIGHT_GRAY);

        JScrollPane scrollPane = new JScrollPane(notificationsPanel);
        add(scrollPane, BorderLayout.CENTER);
        
        // Add back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> goBack());
        add(backButton, BorderLayout.SOUTH);

        // Add sample notifications for demonstration
        addSampleNotifications();
    }

    private void addSampleNotifications() {
        addNotification(new Notification("Rent Request Approved", LocalDateTime.now().toString()));
        addNotification(new Notification("Buy Request Approved", LocalDateTime.now().toString()));
        addNotification(new Notification("Sell Request Rejected", LocalDateTime.now().toString()));
        addNotification(new Notification("Rent Request Rejected", LocalDateTime.now().toString()));
    }

    public void addNotification(Notification notification) {
//        System.out.println("Adding notification: " + notification.getMessage());  // Debug line
        // Determine the color based on the notification message
        Color color = notification.getMessage().toLowerCase().contains("approved") ? Color.GREEN : Color.RED;

        JLabel notificationLabel = new JLabel(notification.getMessage());
        notificationLabel.setFont(new Font("Verdana", Font.PLAIN, 16));
        notificationLabel.setForeground(color); // Set the color based on approval status
        notificationLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Add the label and a small space below it
        notificationsPanel.add(notificationLabel);
        notificationsPanel.add(Box.createRigidArea(new Dimension(0, 5)));

        notificationsPanel.revalidate();
        notificationsPanel.repaint();
    }

    public void refreshNotifications(List<Notification> notifications) {
//        System.out.println("Refreshing notifications: " + notifications.size() + " notifications found.");  // Debug line
        this.notifications = notifications;
        notificationsPanel.removeAll();  // Clear existing notifications first
        
        for (Notification notification : notifications) {
            addNotification(notification);  // Use addNotification to add them back
        }

        notificationsPanel.revalidate();
        notificationsPanel.repaint();
    }

    // Back button action
    private void goBack() {
//        System.out.println("Going back to the previous panel...");
        cardLayout.show(mainPanel, "HomePage"); // Change "HomePage" to the appropriate panel name you want to return to
    }
}
