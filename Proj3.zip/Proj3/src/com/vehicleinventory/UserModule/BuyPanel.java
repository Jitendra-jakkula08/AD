package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BuyPanel extends JPanel {
    public BuyPanel(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());

        JLabel buyLabel = new JLabel("Buy a Vehicle");
        buyLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(buyLabel, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        add(backButton, BorderLayout.SOUTH);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "HomePage");
            }
        });
    }
}
