package com.vehicleinventory.UserModule;

import com.vehicleinventory.Database.VehicleDAO;
import javax.swing.*;
import java.awt.*;

public class SellPagePanel extends JPanel {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private int currentUserId; // Field for user ID
    private JTextField vehicleMakeField; // Field for vehicle make
    private JTextField vehicleModelField; // Field for vehicle model
    private JTextField vehicleYearField; // Field for vehicle year
    private JTextField vehiclePriceField; // Field for vehicle price
    private JTextField vehicleTypeField; // Field for vehicle type
    private JTextField vehicleDescriptionField; // Field for vehicle description
    private JTextField vehicleImageUrlField; // Field for vehicle image URL
    private Image backgroundImage; // Background image

    public SellPagePanel(CardLayout cardLayout, JPanel mainPanel, int currentUserId) {
        this.cardLayout = cardLayout;
        this.mainPanel = mainPanel;
        this.currentUserId = currentUserId; // Initialize user ID

        // Load the background image
        backgroundImage = new ImageIcon("resources/buyvehicle.jpeg").getImage();
        if (backgroundImage == null) {
            System.out.println("Background image not found!");
        } else {
            System.out.println("Background image loaded: " + backgroundImage.getWidth(this) + "x" + backgroundImage.getHeight(this));
        }

        setLayout(new BorderLayout());
        setOpaque(true); // Ensure the panel is opaque

        // Header with title and avatar
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(0, 150, 136));
        headerPanel.setPreferredSize(new Dimension(getWidth(), 150));

        JLabel avatarLabel = new JLabel(new ImageIcon("resources/profile.jpg"));
        if (avatarLabel.getIcon() == null) {
            System.out.println("Profile image not found!");
        } else {
            System.out.println("Profile image loaded.");
        }
        avatarLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(avatarLabel, BorderLayout.NORTH);

        JLabel titleLabel = new JLabel("Sell Vehicle");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        JLabel subtitleLabel = new JLabel("Record of a vehicle's details");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        subtitleLabel.setForeground(Color.WHITE);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(subtitleLabel, BorderLayout.SOUTH);

        add(headerPanel, BorderLayout.NORTH);

        // Main content area
        JPanel sellContentPanel = new JPanel(new GridBagLayout()); // Using GridBagLayout for inputs
        sellContentPanel.setOpaque(false); // Make content panel transparent
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Vehicle make input
        vehicleMakeField = createStyledTextField();
        addField(sellContentPanel, gbc, "Make:", vehicleMakeField, 0);

        // Vehicle model input
        vehicleModelField = createStyledTextField();
        addField(sellContentPanel, gbc, "Model:", vehicleModelField, 1);

        // Vehicle year input
        vehicleYearField = createStyledTextField();
        addField(sellContentPanel, gbc, "Year:", vehicleYearField, 2);

        // Vehicle price input
        vehiclePriceField = createStyledTextField();
        addField(sellContentPanel, gbc, "Price:", vehiclePriceField, 3);

        // Vehicle type input
        vehicleTypeField = createStyledTextField();
        addField(sellContentPanel, gbc, "Type:", vehicleTypeField, 4);

        // Vehicle description input
        vehicleDescriptionField = createStyledTextField();
        addField(sellContentPanel, gbc, "Description:", vehicleDescriptionField, 5);

        // Vehicle image URL input
        vehicleImageUrlField = createStyledTextField();
        addField(sellContentPanel, gbc, "Image URL:", vehicleImageUrlField, 6);

        // Sell button
        JButton sellButton = createStyledButton("Sell Vehicle");
        sellButton.addActionListener(e -> {
            String make = vehicleMakeField.getText().trim();
            String model = vehicleModelField.getText().trim();
            String yearStr = vehicleYearField.getText().trim();
            String priceStr = vehiclePriceField.getText().trim();
            String type = vehicleTypeField.getText().trim(); // Get vehicle type
            String description = vehicleDescriptionField.getText().trim();
            String imageUrl = vehicleImageUrlField.getText().trim();

            // Validate inputs
            if (make.isEmpty() || model.isEmpty() || yearStr.isEmpty() || priceStr.isEmpty() || 
                type.isEmpty() || description.isEmpty() || imageUrl.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                return; // Exit the action listener if validation fails
            }

            // Convert year and price from string to appropriate types
            int year;
            double price;
            try {
                year = Integer.parseInt(yearStr);
                price = Double.parseDouble(priceStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Year must be an integer and Price must be a decimal.");
                return;
            }

            VehicleDAO vehicleDAO = new VehicleDAO();
            String status = "pending"; // Set status to pending by default
            boolean success = vehicleDAO.createSellRequest(currentUserId, make, model, year, price, type, description, imageUrl, status);
            
            if (success) {
                JOptionPane.showMessageDialog(null, "Sell request submitted. Waiting for admin approval.");
                // Clear the fields after submission
                vehicleMakeField.setText("");
                vehicleModelField.setText("");
                vehicleYearField.setText("");
                vehiclePriceField.setText("");
                vehicleTypeField.setText("");
                vehicleDescriptionField.setText("");
                vehicleImageUrlField.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "Error submitting request. Please try again later.");
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        sellContentPanel.add(sellButton, gbc); // Add the button to the panel

        add(sellContentPanel, BorderLayout.CENTER);

        // Back button at the bottom
        JPanel footerPanel = new JPanel();
        footerPanel.setOpaque(false); // Make footer panel transparent
        JButton backButton = createStyledButton("Back");
        footerPanel.add(backButton);
        add(footerPanel, BorderLayout.SOUTH);

        // Back button action
        backButton.addActionListener(e -> {
            cardLayout.show(mainPanel, "HomePage");
        });
    }

    private JTextField createStyledTextField() {
        JTextField textField = new JTextField(25);
        textField.setBorder(BorderFactory.createLineBorder(new Color(0, 150, 136)));
        textField.setFont(new Font("Arial", Font.PLAIN, 16));
        textField.setPreferredSize(new Dimension(250, 35));
        return textField;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0, 150, 136));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(160, 45));
        return button;
    }

    private void addField(JPanel panel, GridBagConstraints gbc, String labelText, JTextField textField, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        panel.add(label, gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(textField, gbc);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw the background image to fill the panel
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            
            // Create a white translucent overlay for better text visibility
            g.setColor(new Color(255, 255, 255, 150)); // 150 is the alpha value for translucency
            g.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}