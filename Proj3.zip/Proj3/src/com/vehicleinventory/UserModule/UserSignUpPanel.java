package com.vehicleinventory.UserModule;

import com.vehicleinventory.Database.UserDAO;
import com.vehicleinventory.Models.User;

import javax.swing.*;
import java.awt.*;

public class UserSignUpPanel extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField emailField;
    private JTextField aadharField;
    private JTextField panField;

    public UserSignUpPanel(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());

        // Left panel for the welcome message and back button
        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setBackground(Color.decode("#2E7D32")); // Green color
        leftPanel.setPreferredSize(new Dimension(400, 0));
        GridBagConstraints gbcLeft = new GridBagConstraints();
        gbcLeft.insets = new Insets(10, 10, 10, 10);
        gbcLeft.anchor = GridBagConstraints.CENTER;

        // Welcome label
        JLabel welcomeLabel = new JLabel("Join Us!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.WHITE);
        gbcLeft.gridx = 0;
        gbcLeft.gridy = 0;
        leftPanel.add(welcomeLabel, gbcLeft);

        // Subtext label
        JLabel subTextLabel = new JLabel("Create an account and start managing your vehicles.");
        subTextLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        subTextLabel.setForeground(Color.WHITE);
        gbcLeft.gridy = 1;
        leftPanel.add(subTextLabel, gbcLeft);

        // Back button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(Color.WHITE);
        backButton.setForeground(Color.decode("#2E7D32"));
        backButton.setPreferredSize(new Dimension(150, 40));
        gbcLeft.gridy = 2;
        leftPanel.add(backButton, gbcLeft);

        add(leftPanel, BorderLayout.WEST);

        // Right panel for the signup form
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50)); // Add padding
        GridBagConstraints gbcRight = new GridBagConstraints();
        gbcRight.insets = new Insets(10, 10, 10, 10);
        gbcRight.anchor = GridBagConstraints.WEST;
        gbcRight.fill = GridBagConstraints.HORIZONTAL;

        // Create Account label
        JLabel createAccountLabel = new JLabel("Create Account");
        createAccountLabel.setFont(new Font("Arial", Font.BOLD, 24));
        createAccountLabel.setForeground(Color.decode("#2E7D32"));
        gbcRight.gridx = 0;
        gbcRight.gridy = 0;
        gbcRight.gridwidth = 2;
        gbcRight.insets = new Insets(0, 0, 20, 0);
        rightPanel.add(createAccountLabel, gbcRight);

        // Username label and field
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 0;
        gbcRight.gridy = 1;
        gbcRight.gridwidth = 1;
        gbcRight.anchor = GridBagConstraints.EAST;
        rightPanel.add(usernameLabel, gbcRight);

        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 1;
        gbcRight.gridy = 1;
        rightPanel.add(usernameField, gbcRight);

        // Email label and field
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 0;
        gbcRight.gridy = 2;
        gbcRight.anchor = GridBagConstraints.EAST;
        rightPanel.add(emailLabel, gbcRight);

        emailField = new JTextField(20);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 1;
        gbcRight.gridy = 2;
        rightPanel.add(emailField, gbcRight);

        // Password label and field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 0;
        gbcRight.gridy = 3;
        gbcRight.anchor = GridBagConstraints.EAST;
        rightPanel.add(passwordLabel, gbcRight);

        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 1;
        gbcRight.gridy = 3;
        rightPanel.add(passwordField, gbcRight);

        // Confirm Password label and field
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 0;
        gbcRight.gridy = 4;
        rightPanel.add(confirmPasswordLabel, gbcRight);

        confirmPasswordField = new JPasswordField(20);
        confirmPasswordField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 1;
        gbcRight.gridy = 4;
        rightPanel.add(confirmPasswordField, gbcRight);

        // Aadhar label and field
        JLabel aadharLabel = new JLabel("Aadhar Number:");
        aadharLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 0;
        gbcRight.gridy = 5;
        rightPanel.add(aadharLabel, gbcRight);

        aadharField = new JTextField(20);
        aadharField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 1;
        gbcRight.gridy = 5;
        rightPanel.add(aadharField, gbcRight);

        // PAN label and field
        JLabel panLabel = new JLabel("PAN Number:");
        panLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 0;
        gbcRight.gridy = 6;
        rightPanel.add(panLabel, gbcRight);

        panField = new JTextField(20);
        panField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbcRight.gridx = 1;
        gbcRight.gridy = 6;
        rightPanel.add(panField, gbcRight);

        // Sign Up button
        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setFont(new Font("Arial", Font.BOLD, 14));
        signUpButton.setBackground(Color.decode("#2E7D32"));
        signUpButton.setForeground(Color.WHITE);
        gbcRight.gridx = 0;
        gbcRight.gridy = 7;
        gbcRight.gridwidth = 2;
        gbcRight.insets = new Insets(20, 0, 0, 0);
        gbcRight.anchor = GridBagConstraints.CENTER;
        rightPanel.add(signUpButton, gbcRight);

        add(rightPanel, BorderLayout.CENTER);

        // Back Button Action Listener
        backButton.addActionListener(e -> cardLayout.show(mainPanel, "UserLogin"));

        // Sign Up Button Action Listener
     signUpButton.addActionListener(e -> {
    String username = usernameField.getText().trim();
    String password = new String(passwordField.getPassword());
    String confirmPassword = new String(confirmPasswordField.getPassword());
    String email = emailField.getText().trim();
    String aadharNumber = aadharField.getText().trim();
    String panNumber = panField.getText().trim();

    // Validate all fields are filled
    if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || email.isEmpty() || aadharNumber.isEmpty() || panNumber.isEmpty()) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Please fill in all fields.");
        return;
    }

    // Check if username already exists
    UserDAO userDAO = new UserDAO();
    if (userDAO.doesUserExist(username)) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Username already exists. Please choose another one.");
        return;
    }

    // Check if email already exists
    if (userDAO.doesEmailExist(email)) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Email already registered. Please use a different email.");
        return;
    }

    // Validate username (must not contain symbols except underscore)
    if (username.matches(".*[^A-Za-z0-9_].*")) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Username can only contain letters, numbers, and underscores. No other symbols are allowed.");
        return;
    }

    // Validate username (alphanumeric + underscore, 3-15 characters)
    if (!username.matches("^[A-Za-z][A-Za-z0-9_]{2,14}$")) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Username must start with a letter, contain no symbols other than underscore, and be 3-15 characters long.");
        return;
    }

    // Validate email format
    if (!email.matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Invalid email format.");
        return;
    }

    // Validate password (must contain letters, symbols, and numbers, and at least 6 characters long)
    if (password.length() < 6 || !password.matches(".*[a-zA-Z].*") || !password.matches(".*\\d.*") || !password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Password must be at least 6 characters long, and contain letters, numbers, and symbols.");
        return;
    }

    // Validate password and confirm password match
    if (!password.equals(confirmPassword)) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Passwords do not match.");
        return;
    }

    // Validate Aadhar number (12 digits, must be numeric, not contain alphabets, and not contain 5 consecutive zeros)
    if (aadharNumber.matches(".*[a-zA-Z].*")) {  // Check if there are alphabets
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Aadhar number cannot contain alphabets.");
        return;
    }

    if (aadharNumber.length() != 12) {  // Check if Aadhar number is exactly 12 digits
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Aadhar number must be exactly 12 digits.");
        return;
    }

    if (aadharNumber.contains("00000")) {  // Check for 5 consecutive zeros
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "Invalid Aadhar Number. It cannot contain 5 consecutive zeros.");
        return;
    }

    // Validate PAN number (10 characters, uppercase alphanumeric)
    if (!panNumber.matches("[A-Z0-9]{10}")) {
        JOptionPane.showMessageDialog(UserSignUpPanel.this, "PAN number must be 10 uppercase alphanumeric characters.");
        return;
    }

    // All validations passed - save user
    User user = new User(username, password, email, aadharNumber, panNumber);
    userDAO.addUser(user);  // Call addUser without expecting a return value

    JOptionPane.showMessageDialog(UserSignUpPanel.this, "Registration successful!");
    cardLayout.show(mainPanel, "UserLogin");
});


    }
    
    public static void main(String[] args) {
        // Create the main frame
        JFrame frame = new JFrame("User Sign Up");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 600); // Adjust size as needed
        frame.setLayout(new BorderLayout());

        // Set up the main panel and card layout for UserSignUpPanel
        JPanel mainPanel = new JPanel(new CardLayout());
        CardLayout cardLayout = (CardLayout) mainPanel.getLayout();
        
        // Create and add UserSignUpPanel to the main panel
        UserSignUpPanel userSignUpPanel = new UserSignUpPanel(cardLayout, mainPanel);
        mainPanel.add(userSignUpPanel, "UserSignUp");

        // Show the UserSignUpPanel on launch
        cardLayout.show(mainPanel, "UserSignUp");

        // Add main panel to frame
        frame.add(mainPanel, BorderLayout.CENTER);

        // Make the frame visible
        frame.setVisible(true);
    }
}
