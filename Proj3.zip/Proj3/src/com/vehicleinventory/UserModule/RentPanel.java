package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RentPanel extends JPanel {
    public RentPanel(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());

        JLabel rentLabel = new JLabel("Rent a Vehicle");
        rentLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(rentLabel, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        add(backButton, BorderLayout.SOUTH);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "HomePage");
            }
        });
    }
}
