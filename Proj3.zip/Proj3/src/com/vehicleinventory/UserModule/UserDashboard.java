package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserDashboard extends JPanel {
    public UserDashboard() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        
        JButton viewVehiclesButton = new JButton("View Vehicles");
        JButton buyVehicleButton = new JButton("Buy Vehicle");
        JButton sellVehicleButton = new JButton("Sell Vehicle");

        viewVehiclesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(UserDashboard.this);
                frame.setContentPane(new ViewVehicles());
                frame.revalidate();
            }
        });

        buyVehicleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(UserDashboard.this);
                frame.setContentPane(new BuyVehicle());
                frame.revalidate();
            }
        });

        sellVehicleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(UserDashboard.this);
//                frame.setContentPane(new SellVehicle());
                frame.revalidate();
            }
        });

        add(viewVehiclesButton);
        add(buyVehicleButton);
        add(sellVehicleButton);
    }
}
