package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProfilePagePanel extends JPanel {
    private static final Logger LOGGER = Logger.getLogger(ProfilePagePanel.class.getName());
    private JLabel nameLabel;
    private JLabel emailLabel;
    private JLabel phoneNumberLabel;
    private JLabel dobLabel;
    private JLabel aadharLabel;  // New label for Aadhar number
    private JLabel panLabel;     // New label for PAN number

    public ProfilePagePanel(CardLayout cardLayout, JPanel mainPanel, int userId) {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 240, 240));

        // Header with navigation buttons
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(240, 240, 240));
        headerPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        JButton updateButton = createStyledButton("Update Details");
        JButton backButton = createStyledButton("Back");

        headerPanel.add(backButton);
        headerPanel.add(updateButton);

        add(headerPanel, BorderLayout.NORTH);

        // Main content area
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(new Color(255, 255, 255));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Reduced padding

        // Photo label (placeholder icon)
        JLabel photoLabel = new JLabel();
        try {
            BufferedImage photoImage = ImageIO.read(getClass().getResource("/resources/icon.jpeg"));
            ImageIcon photoIcon = new ImageIcon(createRoundedImage(photoImage, 80));  // Reduced size
            photoLabel.setIcon(photoIcon);
            photoLabel.setPreferredSize(new Dimension(80, 80));  // Smaller photo
            photoLabel.setHorizontalAlignment(JLabel.CENTER);
            photoLabel.setVerticalAlignment(JLabel.CENTER);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to load photo icon.", e);
        }
        photoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        contentPanel.add(photoLabel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 5)));

        // User details panel
        JPanel userDetailsPanel = new JPanel();
        userDetailsPanel.setLayout(new GridLayout(6, 2, 3, 3));  // Reduced padding between fields
        userDetailsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "User Details"));
        userDetailsPanel.setBackground(Color.WHITE);

        // Initialize user detail labels
        nameLabel = new JLabel();
        emailLabel = new JLabel();
        phoneNumberLabel = new JLabel();
        dobLabel = new JLabel();
        aadharLabel = new JLabel();  // New label
        panLabel = new JLabel();     // New label

        setUserDetails(userId);

        // Customize font and color
        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
        Color labelColor = new Color(50, 50, 50);

        nameLabel.setFont(labelFont);
        emailLabel.setFont(labelFont);
        phoneNumberLabel.setFont(labelFont);
        dobLabel.setFont(labelFont);
        aadharLabel.setFont(labelFont);  // Set font for Aadhar label
        panLabel.setFont(labelFont);     // Set font for PAN label

        nameLabel.setForeground(labelColor);
        emailLabel.setForeground(labelColor);
        phoneNumberLabel.setForeground(labelColor);
        dobLabel.setForeground(labelColor);
        aadharLabel.setForeground(labelColor);  // Set color for Aadhar label
        panLabel.setForeground(labelColor);     // Set color for PAN label

        // Add labels to the details panel
        userDetailsPanel.add(nameLabel);
        userDetailsPanel.add(emailLabel);
        userDetailsPanel.add(phoneNumberLabel);
        userDetailsPanel.add(dobLabel);
        userDetailsPanel.add(aadharLabel);  // Add Aadhar label
        userDetailsPanel.add(panLabel);     // Add PAN label

        contentPanel.add(userDetailsPanel);
        contentPanel.add(Box.createVerticalGlue());

        add(contentPanel, BorderLayout.CENTER);

        // Back button Action Listener
        backButton.addActionListener(e -> cardLayout.show(mainPanel, "HomePage"));

        // Update Button Action Listener
        updateButton.addActionListener(e -> cardLayout.show(mainPanel, "UpdateProfilePage")); // Implement this page
    }

    private void setUserDetails(int userId) {
        switch (userId) {
            case 1:
                nameLabel.setText("Name: Jitu");
                emailLabel.setText("Email: jitu@gmail.com");
                phoneNumberLabel.setText("Phone Number: 9528406241");
                dobLabel.setText("Date of Birth: 09/7/2000");
                aadharLabel.setText("Aadhar Number: 1234 5678 9101");
                panLabel.setText("PAN Number: ABCDE1234F");
                break;
            case 2:
                nameLabel.setText("Name: Navya");
                emailLabel.setText("Email: navya@gmail.com");
                phoneNumberLabel.setText("Phone Number: 8976523467");
                dobLabel.setText("Date of Birth: 08/7/2004");
                aadharLabel.setText("Aadhar Number: 2345 6789 1234");
                panLabel.setText("PAN Number: PQRST5678H");
                break;
            case 3:
                nameLabel.setText("Name: Manisha");
                emailLabel.setText("Email: manisha@gmail.com");
                phoneNumberLabel.setText("Phone Number: 9652976289");
                dobLabel.setText("Date of Birth: 08/7/2003");
                aadharLabel.setText("Aadhar Number: 3456 7890 2345");
                panLabel.setText("PAN Number: LMNOP3456J");
                break;
            case 4:
                nameLabel.setText("Name: Mrudul");
                emailLabel.setText("Email: mrudhul@gmail.com");
                phoneNumberLabel.setText("Phone Number: 8730174920");
                dobLabel.setText("Date of Birth: 09/7/2002");
                aadharLabel.setText("Aadhar Number: 4567 8901 3456");
                panLabel.setText("PAN Number: UVWXY4567K");
                break;
            default:
                nameLabel.setText("Name: Jitu");
                emailLabel.setText("Email: jitu@gmail.com");
                phoneNumberLabel.setText("Phone Number: 9528406241");
                dobLabel.setText("Date of Birth: 09/7/2000");
                aadharLabel.setText("Aadhar Number: 1234 5678 9101");
                panLabel.setText("PAN Number: ABCDE1234F");
        }
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(120, 30));
        button.setBackground(new Color(0, 120, 215));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 90, 170), 2));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(button.getBackground().darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 120, 215));
            }
        });

        return button;
    }

    private BufferedImage createRoundedImage(BufferedImage image, int size) {
        BufferedImage roundedImage = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = roundedImage.createGraphics();
        
        g2d.setClip(new java.awt.geom.Ellipse2D.Double(0, 0, size, size));
        g2d.drawImage(image, 0, 0, size, size, null);
        g2d.dispose();
        
        return roundedImage;
    }

    public void setUserId(int userId) {
        setUserDetails(userId);
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Profile Page");
        CardLayout cardLayout = new CardLayout();
        JPanel mainPanel = new JPanel(cardLayout);
        
        // Example user ID - replace with actual ID retrieved from login process
        int loggedInUserId = 1; 

        // Ensure the constructor is called with the correct parameters
        ProfilePagePanel profilePagePanel = new ProfilePagePanel(cardLayout, mainPanel, loggedInUserId);
        mainPanel.add(profilePagePanel, "ProfilePage");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(mainPanel);
        frame.setSize(600, 600);
        frame.setVisible(true);
    }
}
