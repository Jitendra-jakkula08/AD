package com.vehicleinventory.UserModule;

import com.vehicleinventory.Database.VehicleDAO;
import com.vehicleinventory.Models.Vehicle;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class BuyVehiclePanel extends JPanel {
    private JTable vehicleTable;
    private Image backgroundImage;

    public BuyVehiclePanel(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());

        // Load background image
        try {
            backgroundImage = ImageIO.read(getClass().getClassLoader().getResourceAsStream("resources/buyvehicle.jpeg"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Title Panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(240, 240, 240, 200));
        JLabel titleLabel = new JLabel("Vehicles Available for Sale");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Table to display vehicles
        vehicleTable = createStyledTable();
        JScrollPane scrollPane = new JScrollPane(vehicleTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        // Back button
        JButton backButton = createStyledButton("Back", Color.RED);
        backButton.addActionListener(e -> cardLayout.show(mainPanel, "HomePage"));
        buttonPanel.add(backButton);

        // Buy button
        JButton buyButton = createStyledButton("Buy", new Color(0, 128, 0));
        buyButton.addActionListener(e -> handleBuyAction());
        buttonPanel.add(buyButton);

        add(buttonPanel, BorderLayout.SOUTH);

        loadVehicleData(); // Load initial data
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(new Color(20, 8, 40, 65));
            g2d.fillRect(0, 0, getWidth(), getHeight());
            g2d.dispose();
        }
    }

    private JTable createStyledTable() {
        JTable table = new JTable();
        table.setRowHeight(30);
        table.setShowGrid(true);
        table.setGridColor(Color.LIGHT_GRAY);
        table.setSelectionBackground(new Color(173, 216, 230));
        table.setSelectionForeground(Color.BLACK);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer();
        cellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        cellRenderer.setBackground(new Color(245, 245, 245));
        table.setDefaultRenderer(Object.class, cellRenderer);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 16));
        header.setBackground(new Color(60, 179, 113));
        header.setForeground(Color.WHITE);
        
        return table;
    }

    // Load vehicle data from the database
    public void loadVehicleData() {
        VehicleDAO vehicleDAO = new VehicleDAO();
        List<Vehicle> vehiclesForSale = vehicleDAO.getVehiclesForSale();

        String[] columnNames = {"ID", "Type", "Make", "Model", "Year", "Price", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        for (Vehicle vehicle : vehiclesForSale) {
            Object[] rowData = {
                vehicle.getId(),
                vehicle.getType(),
                vehicle.getMake(),
                vehicle.getModel(),
                vehicle.getYear(),
                vehicle.getPrice(),
                vehicle.getStatus()
            };
            tableModel.addRow(rowData);
        }

        vehicleTable.setModel(tableModel);
        adjustColumnWidths();
    }

    private void adjustColumnWidths() {
        vehicleTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        vehicleTable.getColumnModel().getColumn(1).setPreferredWidth(100);
        vehicleTable.getColumnModel().getColumn(2).setPreferredWidth(150);
        vehicleTable.getColumnModel().getColumn(3).setPreferredWidth(150);
        vehicleTable.getColumnModel().getColumn(4).setPreferredWidth(70);
        vehicleTable.getColumnModel().getColumn(5).setPreferredWidth(100);
        vehicleTable.getColumnModel().getColumn(6).setPreferredWidth(100);
    }

    private void handleBuyAction() {
        int selectedRow = vehicleTable.getSelectedRow();
        if (selectedRow != -1) {
            int vehicleId = (int) vehicleTable.getValueAt(selectedRow, 0);

            VehicleDAO vehicleDAO = new VehicleDAO();
            int userId = 1; // Assuming user ID is hardcoded for now

            vehicleDAO.submitBuyRequest(userId, vehicleId);
            JOptionPane.showMessageDialog(this, "Purchase request submitted for vehicle ID: " + vehicleId);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a vehicle to buy.");
        }
    }

    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setBackground(backgroundColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setPreferredSize(new Dimension(150, 50));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEtchedBorder());
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(button.getBackground().darker());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor);
            }
        });
        return button;
    }

    // This method should be called to refresh the vehicle data after approval
    public void refreshVehicleData() {
        loadVehicleData();
    }

    // Test main method
    public static void main(String[] args) {
        JFrame frame = new JFrame("Buy Vehicle Panel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        CardLayout cardLayout = new CardLayout();
        JPanel mainPanel = new JPanel(cardLayout);

        BuyVehiclePanel buyVehiclePanel = new BuyVehiclePanel(cardLayout, mainPanel);
        mainPanel.add(buyVehiclePanel, "BuyVehiclePanel");

        frame.add(mainPanel);
        frame.setVisible(true);
    }
}
