package com.vehicleinventory.UserModule;

public interface LoginSuccessListener {
    void onLoginSuccess(int userId);
}
