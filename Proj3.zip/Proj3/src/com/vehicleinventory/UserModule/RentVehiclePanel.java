package com.vehicleinventory.UserModule;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RentVehiclePanel extends JPanel {
    public RentVehiclePanel(JPanel mainPanel) {
        setLayout(new BorderLayout());

        // Content for Rent Vehicle
        add(new JLabel("Rent Vehicle", SwingConstants.CENTER), BorderLayout.CENTER);

        // Back button
        JButton backButton = new JButton("Back");
        add(backButton, BorderLayout.SOUTH);

        // Action Listener for back button
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cl = (CardLayout) (mainPanel.getLayout());
                cl.show(mainPanel, "HomePage");
            }
        });
    }
}
