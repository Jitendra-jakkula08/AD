package com.vehicleinventory.UserModule;

import com.vehicleinventory.Database.UserDAO;
import com.vehicleinventory.Models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewProfilePagePanel extends JPanel {
    private JLabel usernameLabel;
    private JLabel emailLabel;
    private JTextField usernameField;
    private JTextField emailField;
    private JButton editProfileButton;
    private UserDAO userDAO;
    private int userId;

    public ViewProfilePagePanel(int userId) {
        this.userId = userId;
        this.userDAO = new UserDAO();
        initializeUI();
        loadUserData();
    }

    private void initializeUI() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Panel to display profile information
        JPanel profilePanel = new JPanel(new GridLayout(3, 2, 10, 10));
        profilePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        usernameLabel = new JLabel("Username:");
        emailLabel = new JLabel("Email:");

        usernameField = new JTextField();
        usernameField.setEditable(false);

        emailField = new JTextField();
        emailField.setEditable(false);

        profilePanel.add(usernameLabel);
        profilePanel.add(usernameField);
        profilePanel.add(emailLabel);
        profilePanel.add(emailField);

        // Edit profile button
        editProfileButton = new JButton("Edit Profile");
        editProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Switch to UpdateProfilePage
                CardLayout cl = (CardLayout) getParent().getLayout();
                cl.show(getParent(), "UpdateProfilePage"); // Ensure UpdateProfilePage exists
            }
        });

        add(profilePanel, BorderLayout.CENTER);
        add(editProfileButton, BorderLayout.SOUTH);
    }

    private void loadUserData() {
        User user = userDAO.getUserById(userId);
        if (user != null) {
            usernameField.setText(user.getUsername());
            emailField.setText(user.getEmail());
        } else {
            JOptionPane.showMessageDialog(this, "Unable to load user profile.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("View Profile");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 300);

            // Creating a CardLayout for switching to an update page if needed
            frame.setLayout(new CardLayout());

            // Adding the profile page panel directly to the frame
            ViewProfilePagePanel profilePanel = new ViewProfilePagePanel(1); // Pass sample userId
            frame.add(profilePanel, "ViewProfilePage");

            // Optional: Placeholder update panel to test switching
            JPanel updateProfilePanel = new JPanel();
            updateProfilePanel.add(new JLabel("Update Profile Page"));
            frame.add(updateProfilePanel, "UpdateProfilePage");

            frame.setVisible(true);
        });
    }
}
