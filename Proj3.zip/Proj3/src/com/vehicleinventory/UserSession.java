package com.vehicleinventory;

public class UserSession {
    private static UserSession instance;
    private int userId;

    private UserSession() {
        userId = 0; // Default to 0 for no user
    }

    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
    
}
