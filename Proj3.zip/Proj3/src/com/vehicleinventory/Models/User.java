package com.vehicleinventory.Models;

public class User {
    private int id;
    private String username;
    private String password;
    private String email;
    private String aadharNumber;
    private String panNumber;

    // No-argument constructor
    public User() {
        this.username = "";
        this.password = "";
        this.email = "";
        this.aadharNumber = "";
        this.panNumber = "";
    }

    // Constructor for adding new users (without id)
    public User(String username, String password, String email, String aadharNumber, String panNumber) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.aadharNumber = aadharNumber;
        this.panNumber = panNumber;
    }

    // Constructor with id (for retrieving from DB)
    public User(int id, String username, String password, String email, String aadharNumber, String panNumber) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.aadharNumber = aadharNumber;
        this.panNumber = panNumber;
    }

    // Existing constructor without aadhar and pan (for backward compatibility)
    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }

    // Constructor with id (for backward compatibility)
    public User(int id, String username, String password, String email) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getAadharNumber() { return aadharNumber; }
    public void setAadharNumber(String aadharNumber) { this.aadharNumber = aadharNumber; }
    public String getPanNumber() { return panNumber; }
    public void setPanNumber(String panNumber) { this.panNumber = panNumber; }
}
