package com.vehicleinventory.Models;

import java.sql.Timestamp;

/**
 * Represents a sale request for a vehicle.
 */
public class SaleRequest {
    private int requestId;                 // Unique identifier for the sale request
    private User user;                      // Associated user making the request
    private String vehicleDescription;      // Description of the vehicle being sold
    private String model;                   // Model of the vehicle
    private double price;                   // Price of the vehicle
    private String imageUrl;                // URL of the vehicle's image
    private String status;                  // Current status of the request (e.g., pending, approved, rejected)
    private Timestamp requestDate;          // Date when the request was made

    /**
     * Constructs a SaleRequest with all properties.
     *
     * @param requestId          Unique identifier for the sale request
     * @param user               Associated user making the request
     * @param vehicleDescription Description of the vehicle being sold
     * @param model              Model of the vehicle
     * @param price              Price of the vehicle
     * @param imageUrl           URL of the vehicle's image
     * @param status             Current status of the request
     * @param requestDate        Date when the request was made
     */
    public SaleRequest(int requestId, User user, String vehicleDescription, String model, double price, String imageUrl, String status, Timestamp requestDate) {
        this.requestId = requestId;
        this.user = user;
        this.vehicleDescription = vehicleDescription;
        this.model = model;
        this.price = price;
        this.imageUrl = imageUrl;
        this.status = status;
        this.requestDate = requestDate;
    }

    /**
     * No-argument constructor.
     */
    public SaleRequest() {
        // Default constructor
    }

    // Getters and Setters
    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getVehicleDescription() {
        return vehicleDescription;
    }

    public void setVehicleDescription(String vehicleDescription) {
        this.vehicleDescription = vehicleDescription;
    }

    public String getModel() {
        return model; // Getter for model
    }

    public void setModel(String model) {
        this.model = model; // Setter for model
    }

    public double getPrice() {
        return price; // Getter for price
    }

    public void setPrice(double price) {
        this.price = price; // Setter for price
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }
}
