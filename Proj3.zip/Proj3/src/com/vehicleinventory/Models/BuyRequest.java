package com.vehicleinventory.Models;

import java.sql.Timestamp;

public class BuyRequest {
    private int requestId;
    private int userId;
    private int vehicleId;
    private Timestamp requestDate;
    private String status;

    // Constructor
    public BuyRequest(int requestId, int userId, int vehicleId, Timestamp requestDate, String status) {
        this.requestId = requestId;
        this.userId = userId;
        this.vehicleId = vehicleId;
        this.requestDate = requestDate;
        this.status = status;
    }

    // Getters and Setters
    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
