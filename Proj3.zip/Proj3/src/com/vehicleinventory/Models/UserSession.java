package com.vehicleinventory.Models;

public class UserSession {
    private static UserSession instance;
    private int userId;
    private String username;
 private User currentUser;
    private UserSession() {}

    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }
     public User getCurrentUser() {
        return currentUser;
    }
}
