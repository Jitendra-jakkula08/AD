package com.vehicleinventory.Models;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

public class RentRequest {
    private int requestId;  // Unique ID for the request
    private User user;      // User object representing the user making the request
    private int vehicleId;  // ID of the vehicle being requested
    private Vehicle vehicle; // Associated Vehicle object
    private Timestamp requestDate; // Timestamp for when the request was made
    private String status;   // Status of the request

    // Added for rental period calculation
    private Date rentStartDate; // Rental start date
    private Date rentEndDate;   // Rental end date

    // Constructor (with rent start and end dates)
    public RentRequest(int requestId, User user, int vehicleId, Vehicle vehicle, Timestamp requestDate, String status, Date rentStartDate, Date rentEndDate) {
        this.requestId = requestId;
        this.user = user;
        this.vehicleId = vehicleId;
        this.vehicle = vehicle;
        this.requestDate = requestDate;
        this.status = status;
        this.rentStartDate = rentStartDate;
        this.rentEndDate = rentEndDate;
    }

    // Constructor (without rent dates, just to create basic RentRequest)
    public RentRequest(int requestId, User user, int vehicleId, Vehicle vehicle, Timestamp requestDate, String status) {
        this.requestId = requestId;
        this.user = user;
        this.vehicleId = vehicleId;
        this.vehicle = vehicle;
        this.requestDate = requestDate;
        this.status = status;
    }

    // Getters and Setters
    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Timestamp getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Timestamp requestDate) {
        this.requestDate = requestDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Rent Start and End Dates
    public Date getRentStartDate() {
        return rentStartDate;
    }

    public void setRentStartDate(Date rentStartDate) {
        this.rentStartDate = rentStartDate;
    }

    public Date getRentEndDate() {
        return rentEndDate;
    }

    // Calculate Rent End Date based on the rental duration
    public void calculateEndDate(int rentalDuration) {
        if (rentStartDate != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(rentStartDate);
            calendar.add(Calendar.DAY_OF_YEAR, rentalDuration); // Add rental duration (in days)
            rentEndDate = calendar.getTime(); // Set the calculated end date
        }
    }

    // Override toString method for easier debugging
    @Override
    public String toString() {
        return "RentRequest{" +
                "requestId=" + requestId +
                ", user=" + user +
                ", vehicleId=" + vehicleId +
                ", vehicle=" + vehicle +
                ", requestDate=" + requestDate +
                ", status='" + status + '\'' +
                ", rentStartDate=" + rentStartDate +
                ", rentEndDate=" + rentEndDate +
                '}';
    }

    // Optional: Add method to check if the rent request is still pending
    public boolean isPending() {
        return "Pending".equalsIgnoreCase(status);
    }
    // Add this method to your RentRequest class
public void setRentEndDate(Date rentEndDate) {
    this.rentEndDate = rentEndDate;
}

}
