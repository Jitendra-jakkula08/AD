package com.vehicleinventory;

import com.vehicleinventory.Models.Notification;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotificationManager {
    private static Map<Integer, List<Notification>> userNotifications = new HashMap<>();

    public static void addNotification(int userId, Notification notification) {
        userNotifications.computeIfAbsent(userId, k -> new ArrayList<>()).add(notification);
    }

    public static List<Notification> getNotifications(int userId) {
        return userNotifications.getOrDefault(userId, new ArrayList<>());
    }

    public static void clearUserNotifications(int userId) {
        userNotifications.remove(userId);
    }
}