package com.vehicleinventory;

import com.vehicleinventory.UserModule.*;
import com.vehicleinventory.AdminModule.*;
import com.vehicleinventory.Database.*;
import com.vehicleinventory.UserSession;
import com.vehicleinventory.Models.Notification;
import com.vehicleinventory.NotificationManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Vehicle Inventory App");
            frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            frame.setSize(800, 600);

            // Add exit confirmation
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                    if (JOptionPane.showConfirmDialog(frame,
                        "Are you sure you want to exit?", "Exit Confirmation",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
                        System.exit(0);
                    }
                }
            });

            // Main panel to switch between different views
            JPanel mainPanel = new JPanel(new CardLayout());
            CardLayout cardLayout = (CardLayout) mainPanel.getLayout();

            // Example user ID for demonstration
            int currentUserId = 1; // Replace this with the actual logged-in user ID from the session
            
            // Initialize NotificationsPanel and pass the CardLayout and mainPanel
            NotificationsPanel notificationsPanel = new NotificationsPanel(cardLayout, mainPanel);
            
            // Load initial notifications
            List<Notification> initialNotifications = NotificationManager.getNotifications(currentUserId);
            notificationsPanel.refreshNotifications(initialNotifications);
            
            // Add notifications panel to the main panel layout
            mainPanel.add(notificationsPanel, "NotificationsPanel");

            // Initialize UserSession for managing user state
            UserSession userSession = UserSession.getInstance();

            // Add the panels to the main panel layout
            mainPanel.add(new UserLoginPanel(cardLayout, mainPanel), "UserLogin");
            mainPanel.add(new UserSignUpPanel(cardLayout, mainPanel), "UserSignUp");
            mainPanel.add(new AdminLoginPanel(cardLayout, mainPanel), "AdminLogin");
            mainPanel.add(new AdminSignUpPanel(cardLayout, mainPanel), "AdminSignUp");
            mainPanel.add(new HomePagePanel(cardLayout, mainPanel), "HomePage");
            mainPanel.add(new HomePageLockedPanel(cardLayout, mainPanel), "HomePageLocked"); // Add locked home page
            mainPanel.add(new ProfilePagePanel(cardLayout, mainPanel, currentUserId), "ProfilePagePanel");
            mainPanel.add(new SettingsPagePanel(cardLayout, mainPanel), "SettingsPagePanel");
            mainPanel.add(new SellPagePanel(cardLayout, mainPanel, currentUserId), "SellPagePanel");
            mainPanel.add(new AdminDashboard(cardLayout, mainPanel), "AdminDashboard");
            mainPanel.add(new RentPagePanel(cardLayout, mainPanel), "RentPagePanel");

            // Add menu bar to switch between User and Admin views
            JMenuBar menuBar = new JMenuBar();
            JMenu menu = new JMenu("Switch");
            JMenuItem userMenuItem = new JMenuItem("User");
            JMenuItem adminMenuItem = new JMenuItem("Admin");

            userMenuItem.addActionListener(e -> cardLayout.show(mainPanel, "UserLogin"));
            adminMenuItem.addActionListener(e -> cardLayout.show(mainPanel, "AdminLogin"));

            menu.add(userMenuItem);
            menu.add(adminMenuItem);
            menuBar.add(menu);
            frame.setJMenuBar(menuBar);

            // Set default panel to HomePageLocked
            cardLayout.show(mainPanel, "HomePageLocked");

            frame.add(mainPanel);
            frame.pack(); // Automatically adjust the frame size based on components
            frame.setVisible(true);
        });
    }
}
