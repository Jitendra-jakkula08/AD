package com.vehicleinventory.Database;

import com.vehicleinventory.Models.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserDAO {
    private static final Logger LOGGER = Logger.getLogger(UserDAO.class.getName());
    private Connection connection;

    public UserDAO() {
        initializeConnection();
    }

    // Initialize the database connection
    private void initializeConnection() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_inventory_db", "root", "Mruh@2023");
            LOGGER.info("Database connection established.");
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to connect to the database.", e);
        }
    }

    // Ensure we have an open connection
    private Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                initializeConnection();
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error checking connection state.", e);
        }
        return connection;
    }

   // Register a new user in the database with Aadhar and PAN
public boolean registerUser(String username, String email, String password, String pan) {
    String sql = "INSERT INTO users (username, password, email, pan) VALUES (?, ?, ?, ?)";
    try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
        stmt.setString(1, username);
        stmt.setString(2, password);
        stmt.setString(3, email);
//        stmt.setString(4, aadhar);
        stmt.setString(5, pan);
        int rowsAffected = stmt.executeUpdate();

        if (rowsAffected > 0) {
            LOGGER.info("User registered successfully.");
            return true;
        } else {
            LOGGER.warning("User registration failed.");
        }
    } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Error executing insert query.", e);
    }
    return false;
}

// Add a user with Aadhar and PAN
// Add a user with Aadhar and PAN
public void addUser(User user) {
    String sql = "INSERT INTO users (username, password, email, aadharnumber, pannumber) VALUES (?, ?, ?, ?, ?)";
    try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
        stmt.setString(1, user.getUsername());
        stmt.setString(2, user.getPassword());
        stmt.setString(3, user.getEmail());
        stmt.setString(4, user.getAadharNumber());
        stmt.setString(5, user.getPanNumber());
        int rowsAffected = stmt.executeUpdate();

        if (rowsAffected > 0) {
            LOGGER.info("User added successfully.");
        } else {
            LOGGER.warning("User not added.");
        }
    } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Error executing insert query.", e);
    }
}


// Update a user with Aadhar and PAN
public void updateUser(User user) {
    String sql = "UPDATE users SET username = ?, password = ?, email = ?, aadhar = ?, pan = ? WHERE id = ?";
    try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
        stmt.setString(1, user.getUsername());
        stmt.setString(2, user.getPassword());
        stmt.setString(3, user.getEmail());
        stmt.setString(4, user.getAadharNumber());
        stmt.setString(5, user.getPanNumber());
        stmt.setInt(6, user.getId());
        int rowsAffected = stmt.executeUpdate();

        if (rowsAffected > 0) {
            LOGGER.info("User updated successfully.");
        } else {
            LOGGER.warning("User not updated.");
        }
    } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Error executing update query.", e);
    }
}

// Delete a user by ID (no change needed for Aadhar and PAN)
public void deleteUser(int id) {
    String sql = "DELETE FROM users WHERE id = ?";
    try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
        stmt.setInt(1, id);
        int rowsAffected = stmt.executeUpdate();

        if (rowsAffected > 0) {
            LOGGER.info("User deleted successfully.");
        } else {
            LOGGER.warning("User not deleted.");
        }
    } catch (SQLException e) {
        LOGGER.log(Level.SEVERE, "Error executing delete query.", e);
    }
}

    // Get a user by ID
    public User getUserById(int id) {
        if (id <= 0) {
            LOGGER.warning("Invalid user ID: " + id);
            return null;
        }

        String sql = "SELECT * FROM users WHERE id = ?";
        try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                LOGGER.log(Level.INFO, "User with ID {0} found.", id);
                return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email")
                );
            } else {
                LOGGER.warning("User with ID " + id + " not found.");
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error executing select query for user ID " + id, e);
        }
        return null;
    }

    // Get a user by username
    public User getUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (PreparedStatement stmt = getConnection().prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                LOGGER.log(Level.INFO, "User with username {0} found.", username);
                return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email")
                );
            } else {
                LOGGER.warning("User with username " + username + " not found.");
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error executing select query for username " + username, e);
        }
        return null;
    }

    // Get all users
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users";
        try (Statement stmt = getConnection().createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                users.add(new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email")
                ));
            }
            LOGGER.info("All users retrieved successfully.");
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error executing select query.", e);
        }
        return users;
    }

    // Get user by ID with a default return option
    public User getUserByIdOrDefault(int id) {
        User user = getUserById(id);
        if (user == null) {
            LOGGER.warning("Returning default user for ID " + id);
            return new User(0, "Guest", "", "guest@example.com");
        }
        return user;
    }
    
    public boolean doesUserExist(String username) {
        String query = "SELECT COUNT(*) FROM users WHERE username = ?";
        
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();
            
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0; // Returns true if user exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // User does not exist
    }

    // Method to check if email already exists
    public boolean doesEmailExist(String email) {
        String query = "SELECT COUNT(*) FROM users WHERE email = ?";
        
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();
            
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0; // Returns true if email exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Email does not exist
    }
    

    // Close the database connection
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                LOGGER.info("Database connection closed successfully.");
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error closing the connection.", e);
        }
    }
}
