package com.vehicleinventory.Database;

import com.vehicleinventory.Models.RentRequest;
import com.vehicleinventory.Models.User; // Ensure you have the User model imported
import com.vehicleinventory.Models.Vehicle;
import com.vehicleinventory.Models.SaleRequest; // Add this line
import com.vehicleinventory.Models.BuyRequest;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VehicleDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/vehicle_inventory_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Mruh@2023";

    public VehicleDAO() {
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    public boolean createSellRequest(int userId, String make, String model, int year, double price, String type, String description, String imageUrl, String status) {
    String sql = "INSERT INTO sale_requests (user_id, vehicle_description, image_url, status, request_date) VALUES (?, ?, ?, ?, NOW())";
    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(sql)) {
        // Set parameters for the prepared statement
        stmt.setInt(1, userId);
        stmt.setString(2, description); // Vehicle description
        stmt.setString(3, imageUrl);     // Image URL
        stmt.setString(4, status);        // Status ("pending")

        // Execute the update and check for success
        int rowsAffected = stmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Sell request created for user ID: " + userId);
            return true; // Successfully created the sell request
        } else {
            System.err.println("No rows affected. Sell request creation failed.");
            return false; // Creation failed
        }
    } catch (SQLException e) {
        System.err.println("Error creating sell request: " + e.getMessage());
        return false; // Return false on exception
    }
}


    public boolean createBuyRequest(int userId, int vehicleId) {
        String sql = "INSERT INTO buy_requests (user_id, vehicle_id, status) VALUES (?, ?, 'Pending')";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, vehicleId);
            stmt.executeUpdate();
            return true; // Success
        } catch (SQLException e) {
            System.err.println("Error creating buy request: " + e.getMessage());
            return false; // Failure
        }
    }

    public List<RentRequest> getPendingRentRequests() {
        List<RentRequest> requests = new ArrayList<>();
        String query = "SELECT id, user_id, vehicle_id, request_date, status FROM rent_requests WHERE status = 'Pending'";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                int userId = rs.getInt("user_id"); // Get the user ID
                User user = getUserById(userId); // Fetch the User object
                int vehicleId = rs.getInt("vehicle_id");
                Vehicle vehicle = getVehicleById(vehicleId); // Fetch the vehicle object

                requests.add(new RentRequest(
                        rs.getInt("id"), // requestId
                        user, // Pass the User object
                        vehicleId, // vehicleId
                        vehicle, // Pass the Vehicle object
                        rs.getTimestamp("request_date"), // requestDate
                        rs.getString("status") // status
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving pending rent requests: " + e.getMessage());
        }

        return requests;
    }

    public boolean createSellRequest(int userId, String make, String model, int year, double price, String status, String description, String imageUrl) {
        String sql = "INSERT INTO sale_requests (user_id, vehicle_description, image_url, status, make, model, year, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            
            // Set parameters
            preparedStatement.setInt(1, userId);
            preparedStatement.setString(2, description); // Assuming description as the vehicle description
            preparedStatement.setString(3, imageUrl);
            preparedStatement.setString(4, status);
            preparedStatement.setString(5, make);
            preparedStatement.setString(6, model);
            preparedStatement.setInt(7, year);
            preparedStatement.setDouble(8, price);
            
            // Execute the insert
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Returns true if insert was successful
            
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exceptions appropriately
            return false;
        }
    }
    
    

    public boolean addVehicle(Vehicle vehicle) {
        String sql = "INSERT INTO vehicles (make, model, year, price, status, description, image_url, isAvailableForRent, isAvailableForSale) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, vehicle.getMake());
            stmt.setString(2, vehicle.getModel());
            stmt.setInt(3, vehicle.getYear());
            stmt.setDouble(4, vehicle.getPrice());
            stmt.setString(5, vehicle.getStatus());
            stmt.setString(6, vehicle.getDescription());
            stmt.setString(7, vehicle.getImageUrl());
            stmt.setBoolean(8, vehicle.isAvailableForRent());
            stmt.setBoolean(9, vehicle.isAvailableForSale());
            stmt.executeUpdate();
            return true; // Success
        } catch (SQLException e) {
            System.err.println("Error adding vehicle: " + e.getMessage());
            return false; // Failure
        }
    }

    public boolean updateVehicle(Vehicle vehicle) {
        String sql = "UPDATE vehicles SET make = ?, model = ?, year = ?, price = ?, status = ?, description = ?, image_url = ?, isAvailableForRent = ?, isAvailableForSale = ? WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, vehicle.getMake());
            stmt.setString(2, vehicle.getModel());
            stmt.setInt(3, vehicle.getYear());
            stmt.setDouble(4, vehicle.getPrice());
            stmt.setString(5, vehicle.getStatus());
            stmt.setString(6, vehicle.getDescription());
            stmt.setString(7, vehicle.getImageUrl());
            stmt.setBoolean(8, vehicle.isAvailableForRent());
            stmt.setBoolean(9, vehicle.isAvailableForSale());
            stmt.setInt(10, vehicle.getId());
            stmt.executeUpdate();
            return true; // Success
        } catch (SQLException e) {
            System.err.println("Error updating vehicle: " + e.getMessage());
            return false; // Failure
        }
    }

  public boolean approveSellRequest(int requestId) {
    try (Connection connection = getConnection()) {
        // Update the request status to approved
        String updateRequestQuery = "UPDATE sale_requests SET status = 'approved' WHERE request_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(updateRequestQuery)) {
            stmt.setInt(1, requestId);
            stmt.executeUpdate();
        }

        // Now update the vehicle to be available for sale
        String selectVehicleQuery = "SELECT vehicle_id FROM sale_requests WHERE request_id = ?";
        int vehicleId = 0;
        try (PreparedStatement stmt = connection.prepareStatement(selectVehicleQuery)) {
            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                vehicleId = rs.getInt("vehicle_id");
            }
        }

        String updateVehicleQuery = "UPDATE vehicles SET isAvailableForSale = 1 WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(updateVehicleQuery)) {
            stmt.setInt(1, vehicleId);
            stmt.executeUpdate();
        }

        return true; // Success
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


    public Vehicle getVehicleById(int id) {
        String sql = "SELECT * FROM vehicles WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Vehicle(
                        rs.getInt("id"),
                        rs.getString("type") != null ? rs.getString("type") : "Unknown", // Fetching type
                        rs.getString("make") != null ? rs.getString("make") : "Unknown",
                        rs.getString("model") != null ? rs.getString("model") : "Unknown",
                        rs.getInt("year"),
                        rs.getDouble("price"),
                        rs.getString("status") != null ? rs.getString("status") : "Unknown",
                        rs.getString("description") != null ? rs.getString("description") : "No Description",
                        rs.getString("image_url"),
                        rs.getBoolean("isAvailableForRent"),
                        rs.getBoolean("isAvailableForSale")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving vehicle: " + e.getMessage());
        }
        return null; // Vehicle not found
    }

    public List<Vehicle> getAvailableVehiclesForRent() {
        List<Vehicle> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM vehicles WHERE isAvailableForRent = true"; // Adjust based on your DB schema
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Vehicle vehicle = new Vehicle(
                        rs.getInt("id"),
                        rs.getString("type") != null ? rs.getString("type") : "Unknown", // Assuming 'type' is a valid column
                        rs.getString("make") != null ? rs.getString("make") : "Unknown",
                        rs.getString("model") != null ? rs.getString("model") : "Unknown",
                        rs.getInt("year"),
                        rs.getDouble("price"),
                        rs.getString("status") != null ? rs.getString("status") : "Unknown",
                        rs.getString("description") != null ? rs.getString("description") : "No Description",
                        rs.getString("image_url"),
                        rs.getBoolean("isAvailableForRent"),
                        rs.getBoolean("isAvailableForSale")
                );
                vehicles.add(vehicle);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving available vehicles for rent: " + e.getMessage());
        }
        return vehicles;
    }

    public List<Vehicle> getAllVehicles() {
        List<Vehicle> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM vehicles"; // Adjust this SQL to match your table schema
        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Vehicle vehicle = new Vehicle(
                        rs.getInt("id"),
                        rs.getString("type") != null ? rs.getString("type") : "Unknown",
                        rs.getString("make") != null ? rs.getString("make") : "Unknown",
                        rs.getString("model") != null ? rs.getString("model") : "Unknown",
                        rs.getInt("year"),
                        rs.getDouble("price"),
                        rs.getString("status") != null ? rs.getString("status") : "Unknown",
                        rs.getString("description") != null ? rs.getString("description") : "No Description",
                        rs.getString("image_url"),
                        rs.getBoolean("isAvailableForRent"),
                        rs.getBoolean("isAvailableForSale")
                );
                vehicles.add(vehicle);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving all vehicles: " + e.getMessage());
        }
        return vehicles;
    }
    

    private User getUserById(int userId) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving user: " + e.getMessage());
        }
        return null; // Return null if user is not found
    }
    
  // Assuming you are creating a SaleRequest somewhere in your code, e.g., in a method
public List<SaleRequest> getPendingSaleRequests() {
    List<SaleRequest> pendingRequests = new ArrayList<>();
    String sql = "SELECT * FROM sale_requests WHERE status = 'Pending'";

    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            int requestId = rs.getInt("request_id");
            int userId = rs.getInt("user_id");
            String vehicleDescription = rs.getString("vehicle_description");
            String model = rs.getString("model"); // Ensure this field exists in your table
            double price = rs.getDouble("price"); // Ensure this field exists in your table
            String imageUrl = rs.getString("image_url");
            String status = rs.getString("status");
            Timestamp requestDate = rs.getTimestamp("request_date"); // If needed

            User user = getUserById(userId); // Fetch the user based on userId

            SaleRequest request = new SaleRequest(requestId, user, vehicleDescription, model, price, imageUrl, status, requestDate);
            pendingRequests.add(request);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return pendingRequests;
}


 public boolean rejectSellRequest(int requestId) {
        String query = "UPDATE sale_requests SET status = 'Rejected' WHERE request_id = ?";

        try (Connection connection = DatabaseConnection.getConnection(); // Ensure you have a method to get a DB connection
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, requestId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0; // Return true if at least one row was updated
        } catch (SQLException e) {
            System.err.println("Error rejecting sell request: " + e.getMessage());
            return false; // Return false in case of an error
        }
    }
 
 
 
 public List<Vehicle> getVehiclesForSale() {
    List<Vehicle> vehiclesForSale = new ArrayList<>();
    String sql = "SELECT id, type, make, model, year, price, status, description, image_url, isAvailableForRent, isAvailableForSale FROM vehicles WHERE isAvailableForSale = 1";

    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            int id = rs.getInt("id");
            String type = rs.getString("type");
            String make = rs.getString("make");
            String model = rs.getString("model");
            int year = rs.getInt("year");
            double price = rs.getDouble("price");
            String status = rs.getString("status");
            String description = rs.getString("description");
            String imageUrl = rs.getString("image_url");
            boolean isAvailableForRent = rs.getBoolean("isAvailableForRent");
            boolean isAvailableForSale = rs.getBoolean("isAvailableForSale");

            // Use the constructor with all fields
            Vehicle vehicle = new Vehicle(id, type, make, model, year, price, status, description, imageUrl, isAvailableForRent, isAvailableForSale);
            vehiclesForSale.add(vehicle);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return vehiclesForSale;
}


 
 public void submitBuyRequest(int userId, int vehicleId) {
    String sql = "INSERT INTO buy_requests (user_id, vehicle_id, request_date, status) VALUES (?, ?, NOW(), 'pending')";
    try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, userId);
        stmt.setInt(2, vehicleId);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

 
 public List<BuyRequest> getPendingBuyRequests() {
        List<BuyRequest> requests = new ArrayList<>();
        String query = "SELECT * FROM buy_requests WHERE status = 'pending'";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_inventory_db", "root", "Mruh@2023");
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                BuyRequest request = new BuyRequest(
                    rs.getInt("request_id"),
                    rs.getInt("user_id"),
                    rs.getInt("vehicle_id"),
                    rs.getTimestamp("request_date"),
                    rs.getString("status")
                );
                requests.add(request);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return requests;
    }

   public int approveBuyRequest(int requestId) {
    String query = "UPDATE buy_requests SET status = 'approved' WHERE request_id = ?";
    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_inventory_db", "root", "Mruh@2023");
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setInt(1, requestId);
        // Execute the update and get the number of affected rows
        int rowsAffected = stmt.executeUpdate();
        return rowsAffected; // Return the number of affected rows (1 if successful, 0 if not)
    } catch (SQLException e) {
        e.printStackTrace();
        return 0; // Return 0 in case of an error
    }
}

    public void rejectBuyRequest(int requestId) {
        String query = "UPDATE buy_requests SET status = 'rejected' WHERE request_id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_inventory_db", "root", "Mruh@2023");
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, requestId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public BuyRequest getBuyRequestById(int requestId) {
        BuyRequest buyRequest = null;
        String query = "SELECT * FROM buy_requests WHERE request_id = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
             
            statement.setInt(1, requestId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                buyRequest = new BuyRequest(
                    resultSet.getInt("request_id"),
                    resultSet.getInt("user_id"),
                    resultSet.getInt("vehicle_id"),
                    resultSet.getTimestamp("request_date"),
                    resultSet.getString("status")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception properly
        }

        return buyRequest;
    }
 
    
    
    
    
    
    
    
}
