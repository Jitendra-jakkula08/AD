package com.vehicleinventory.Database;

import com.vehicleinventory.Models.RentRequest;
import com.vehicleinventory.Models.User;
import com.vehicleinventory.Models.UserSession;
import com.vehicleinventory.Models.Vehicle;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RentRequestDAO {

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_inventory_db", "root", "Mruh@2023");
    }

    public int createRentRequest(int vehicleId) {
    int userId = UserSession.getInstance().getUserId();
    if (userId <= 0) {
        System.err.println("Invalid user ID.");
        return -1; // Return -1 to indicate an error
    }

    String sql = "INSERT INTO rent_requests (user_id, vehicle_id, request_date, status) VALUES (?, ?, NOW(), 'pending')";

    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

        stmt.setInt(1, userId);
        stmt.setInt(2, vehicleId);
        int rowsAffected = stmt.executeUpdate();

        if (rowsAffected > 0) {
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1); // Return the generated request ID
                }
            }
        }
    } catch (SQLException e) {
        System.err.println("Error creating rent request: " + e.getMessage());
    }
    return -1; // Return -1 if request ID is not generated
}


    public List<RentRequest> getPendingRentRequests() {
        List<RentRequest> requests = new ArrayList<>();
        String sql = "SELECT * FROM rent_requests WHERE status = 'pending'";

        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int userId = rs.getInt("user_id"); // Get user_id from rent_requests
                User user = getUserById(userId); // Fetch the User object
                int vehicleId = rs.getInt("vehicle_id");
                Vehicle vehicle = getVehicleById(vehicleId); // Fetch the Vehicle object

                RentRequest request = new RentRequest(
                        rs.getInt("request_id"),
                        user, // Pass the User object
                        vehicleId,
                        vehicle, // Pass the Vehicle object
                        rs.getTimestamp("request_date"),
                        rs.getString("status")
                );
                requests.add(request);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching pending rent requests: " + e.getMessage());
        }

        return requests;
    }

    private User getUserById(int userId) {
        String sql = "SELECT * FROM users WHERE id = ?"; // Ensure this matches your DB schema
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving user: " + e.getMessage());
        }
        return null; // Return null if user is not found
    }

    private Vehicle getVehicleById(int vehicleId) {
        String sql = "SELECT * FROM vehicles WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vehicleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Vehicle(
                        rs.getInt("id"),
                        rs.getString("type"), // Make sure 'type' exists in your DB schema
                        rs.getString("make"),
                        rs.getString("model"),
                        rs.getInt("year"),
                        rs.getDouble("price"),
                        rs.getString("status"),
                        rs.getString("description"),
                        rs.getString("image_url"),
                        rs.getBoolean("isAvailableForRent"),
                        rs.getBoolean("isAvailableForSale")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving vehicle: " + e.getMessage());
        }
        return null; // Return null if vehicle is not found
    }
    
    public void createRentalDetail(int requestId, String username, int rentalDuration, String additionalNotes) {
        String sql = "INSERT INTO rental_details (request_id, username, rental_duration, additional_notes) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            stmt.setString(2, username);
            stmt.setInt(3, rentalDuration);
            stmt.setString(4, additionalNotes);

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void approveRentRequest(int requestId) {
        updateRequestStatus(requestId, "approved");
    }

    public void rejectRentRequest(int requestId) {
        updateRequestStatus(requestId, "rejected");
    }

    private void updateRequestStatus(int requestId, String newStatus) {
        String sql = "UPDATE rent_requests SET status = ? WHERE request_id = ?";

        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setString(1, newStatus);
            stmt.setInt(2, requestId);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Rent request status updated to: " + newStatus);
            } else {
                System.out.println("No rent request found with ID: " + requestId);
            }
        } catch (SQLException e) {
            System.err.println("Error updating rent request status: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        RentRequestDAO rentRequestDAO = new RentRequestDAO();

        UserSession userSession = UserSession.getInstance();
        int userId = userSession.getUserId();

        if (userId == 0) {
            System.err.println("User ID is 0. Please log in properly.");
            return;
        }

        int vehicleId = 2; // Ensure this vehicle ID exists in your database
        rentRequestDAO.createRentRequest(vehicleId);

        List<RentRequest> pendingRequests = rentRequestDAO.getPendingRentRequests();
        System.out.println("Pending Rent Requests:");
        for (RentRequest request : pendingRequests) {
            System.out.println(request);
        }

        // Approve a rent request
        if (!pendingRequests.isEmpty()) {
            int requestIdToApprove = pendingRequests.get(0).getRequestId();
            rentRequestDAO.approveRentRequest(requestIdToApprove);
        }

        // Reject a rent request
        if (!pendingRequests.isEmpty()) {
            int requestIdToReject = pendingRequests.get(0).getRequestId();
            rentRequestDAO.rejectRentRequest(requestIdToReject);
        }
    }
}
