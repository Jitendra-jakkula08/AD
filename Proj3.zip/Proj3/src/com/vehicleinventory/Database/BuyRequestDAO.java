package com.vehicleinventory.Database;

import com.vehicleinventory.Models.UserSession;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BuyRequestDAO {
    // This method provides a connection to the database
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle_inventory_db", "root", "Mruh@2023");
    }

    // This method creates a buy request for the specified user and vehicle
    public void createBuyRequest(int vehicleId) {
        int userId = UserSession.getInstance().getUserId();
        if (userId <= 0) {
            System.err.println("Invalid user ID.");
            return;
        }

        String sql = "INSERT INTO buy_requests (user_id, vehicle_id, request_date, status) VALUES (?, ?, NOW(), 'pending')";

        try (Connection connection = getConnection(); // Get a connection from the method
             PreparedStatement pstmt = connection.prepareStatement(sql)) {

            pstmt.setInt(1, userId); // Set the user_id
            pstmt.setInt(2, vehicleId); // Set the vehicle_id

            int rowsAffected = pstmt.executeUpdate(); // Execute the insert
            if (rowsAffected > 0) {
                System.out.println("Buy request created successfully.");
            } else {
                System.out.println("Failed to create buy request.");
            }
        } catch (SQLException e) {
            System.err.println("Error creating buy request: " + e.getMessage());
        }
    }

    // Main method for debugging
    public static void main(String[] args) {
        BuyRequestDAO buyRequestDAO = new BuyRequestDAO();

        // Simulate user session
        UserSession userSession = UserSession.getInstance();
        userSession.setUserId(1); // Set a valid user ID for testing purposes

        int vehicleId = 2; // Ensure this vehicle ID exists in your database for the test
        System.out.println("Attempting to create a buy request for vehicle ID: " + vehicleId);
        buyRequestDAO.createBuyRequest(vehicleId);

        // For debugging purposes, you can check if the user session is properly set
        System.out.println("Current User ID in session: " + userSession.getUserId());
    }
}
