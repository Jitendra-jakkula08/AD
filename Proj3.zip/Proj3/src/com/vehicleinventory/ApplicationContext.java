package com.vehicleinventory;

public class ApplicationContext {
    private static int loggedInUserId = -1; // Use -1 as an indicator for no user logged in

    public static void setLoggedInUserId(int userId) {
        loggedInUserId = userId;
    }

    public static int getLoggedInUserId() {
        return loggedInUserId;
    }
}
